#include <vector>
#include <cmath>
#include <complex>
#include <iostream>
#include <fftw3.h>
#include "mex.h"
#include "header/GSchur.h"
#include "header/Toeplitz.h"
#include "header/NormalToeplitz.h"

// This function computes the log-likelihood

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs != 2) {
        mexErrMsgIdAndTxt("InvalidInput", "Two input arguments required.");
    }

    // Get input data from MATLAB
    const double *acf = mxGetPr(prhs[0]);
    const double *z = mxGetPr(prhs[1]);
    //mwSize n = mxGetM(prhs[0]);
    //double* acf = mxGetPr(prhs[0]);
    int n = mxGetNumberOfElements(prhs[0]);
    int m = mxGetN(prhs[1]);
    // Create a Toeplitz structure
    NormalToeplitz Tz(n);

    Tz.set_acf(acf);
    //Tz.set_z(z); 
    
    plhs[0] = mxCreateDoubleMatrix(1, m, mxREAL);
    double *res = mxGetPr(plhs[0]); // Allocate memory for the result

    // If z is a matrix:
    for (int i = 0; i < m; i++) {
        Tz.set_z(z + i * n);  // for the i-th column of z
        res[i] = Tz.logdens();  // call the Cpp function for the i-th column
    }

   // delete[] res;  
}
