% Minimize l2 loss function for dynamic image structure function(Dqt) with fixed A(q) and B, and return estimated parameters and mean squared displacement(MSD).
% Input:
%    param: a vector of natural logarithm of parameters
%    q: wave vector in unit of um^-1
%    index_q: selected index of wave number
%    Dqt: observed dynamic image structure function.
%    A_est_q: estimated value of A(q). This parameter is determined by the properties of the imaged material and imaging optics.
%    B_est: estimated value of B. This parameter is determined by the noise in the system. 
%    d_input: sequence of lag times
%    model_name: model for constructing MSD, options from ('BM', 'OU','FBM', 'OU+FBM', 'user_defined')
%    msd_fn: user-defined mean squared displacement structure (MSD), a function of "param" parameters and "d_input" lag times
%    msd_grad_fn: user-defined MSD gradient structure, a function of "param" and "d_input" 
% Output:
%    A list of estimated parameters and MSD from minimizing the l2 loss function.

function ddm_result = theta_est_l2_dqt_fixedAB(param, q, index_q, Dqt, A_est_q, B_est, d_input, model_name, msd_fn, msd_grad_fn)
    param_est_l2 = NaN(length(q), length(param));

    for q_j = index_q
      
        fun = @(param_vec) l2_fixedAB(param_vec, Dqt(q_j,:), q(q_j),A_est_q(q_j), B_est, d_input,... 
                                  model_name, msd_fn, msd_grad_fn);
 
%           options = optimoptions('fmincon','GradConstr','off');  
%           options = optimoptions(options,'GradObj','off');  
%           %options = optimoptions(options,'MaxIterations',100);
%           options = optimoptions(options,'StepTolerance',10^(-6));
%           %options = optimoptions(options,'FunctionTolerance',10^(-6));
%           options = optimoptions(options,'Display','off');
%           options = optimoptions(options,'HessianApproximation','lbfgs');
%           A = [];
%           b = [];
%           Aeq = [];
%           beq = [];
%           lb = [];
%           ub = [];
%           nonlcon = [];
%   
%           param_est_l2(q_j, :) = fmincon(fun, param, A,b,Aeq,beq,lb,ub,nonlcon,options);
%           try_num = 1;
%           while any(abs(param_est_l2(q_j, :)) > 50) && try_num < 10
%              param_est_l2(q_j, :) = fmincon(fun, param+rand(1,length(param)), A,b,Aeq,beq,lb,ub,nonlcon,options);
%              try_num = try_num + 1;
%           end    
          
%         %  if any(abs(param_est_l2(q_j, :)) > 50)
%             %%% Use a gradient-free method for optim:
%             options_funval = optimset('fminsearch');
%             %options_funval.MaxIter = 100;
%             options_funval.Display = "off";
%             param_est_l2(q_j, :) = fminsearch(fun, param, options_funval);
%        %   end    
     
           options_here = optimoptions('fminunc','MaxIterations',100);  
           options_here = optimoptions(options_here,'StepTolerance',10^(-8));
           %options = optimoptions(options,'FunctionTolerance',10^(-6));
           options_here = optimoptions(options_here,'Display','off');
           options_here = optimoptions(options_here,'HessianApproximation','lbfgs');
 
           param_est_l2(q_j, :) = fminunc(fun, param, options_here);    
    end

    param_ddm_mat = zeros(length(q), length(param));

    for i = 1:size(param_est_l2, 1)
        params = exp(param_est_l2(i,:));
        param_ddm_mat(i,:) = get_est_param(params, model_name);
    end
 
    param_ddm = mean(param_ddm_mat, 'omitnan');
    
    msd_ddm = get_MSD(param_ddm, d_input, model_name, msd_fn);
    
    ddm_result.param_est = param_ddm;
    ddm_result.msd_est = msd_ddm;
end

