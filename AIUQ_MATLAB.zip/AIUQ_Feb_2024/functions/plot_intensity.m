% Function to plot 2D intensity profile for a certain frame, default is to plot the first frame. Input can be a matrix (2D) or an array (3D).
% Input:
%    intensity: intensity profile
%    intensity_str: structure of the intensity profile, options from ("SST_array","S_ST_mat","T_SS_mat", "SS_T_mat").
%    frame: frame index
%    plot_title: main title of the plot. If NA, title is "intensity profile for frame n" with n being the frame index in frame.
%    color: a logical evaluating to TRUE or FALSE indicating whether a colorful plot is generated 
% Output:
%    2D plot in gray scale (or with color) of selected frame.

function plot_intensity(intensity, intensity_str, frame, plot_title, color)

    if nargin < 2 || ~ischar(intensity_str)
        intensity_str = "T_SS_mat";
    end
 
    if nargin < 3 || isnan(frame)
        frame = 1;
    end

    if nargin < 4 || ~isstring(plot_title)
        plot_title = ['Intensity profile for frame ', num2str(frame)];
    end

    if nargin < 5 || isnan(color)
        color = false;
    end

    if strcmp(intensity_str, 'SS_T_mat')
        intensity_trans = intensity;
    else
        intensity_trans = intensity_format_transform(intensity, intensity_str);
    end

    sz = sqrt(length(intensity_trans(:, 1)));

    if ~color
        figure('Position', [500 500 285 220]);
        imagesc('XData', [0 1], 'YData', [0 1], 'CData',reshape(intensity_trans(:, frame), sz, sz));
        colormap(gray(256));
        colorbar;
    else
        figure('Position', [500 500 285 220]);
        imagesc('XData', [0 1], 'YData', [0 1], 'CData', reshape(intensity_trans(:, frame), sz, sz));
        colormap(jet);
        colorbar;
    end
    xlim([0 1]);
    ylim([0 1]);
    xlabel('x');
    ylabel('y');
    title(plot_title);
end
