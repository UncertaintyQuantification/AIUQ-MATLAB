% This function construct the lower and upper bound for 95% confidence interval of estimated parameters for the given model, including parameters contained in the intermediate scattering function and background noise.
% Input:
%   param_est: a vector of natural logarithm of estimated parameters from maximize the log likelihood. This vector will serve as initial values in the optim function.
%   I_q_cur: Fourier transformed intensity profile
%   B_cur: current value of B. This parameter is determined by the noise in the system. 
%   index_q: selected index of wave number
%   I_o_q_2_ori: absolute square of Fourier transformed intensity profile,en semble over time
%   q_ori_ring_loc_unique_index: index for wave vector that gives a unique frequency
%   sz: frame size of the intensity profile
%   len_t: number of time steps
%   d_input: sequence of lag times
%   q: wave vector in units of um^-1
%   model_name: model for constructing MSD, options from ('BM', 'OU','FBM', 'OU+FBM', 'user_defined')
%   estimation_method: method for constructing 95% confidence interval, default is asymptotic
%   M: number of particles
%   num_iteration_max: the maximum number of iterations in optim
%   lower_bound: lower bound for the "L-BFGS-B" method in optim
%   msd_grad_fn: user defined MSD gradient structure, a function of param_est and d_input
% Output:
%   A matrix of lower and upper bound for natural logarithm of parameters in the fitted model using AIUQ method in SAM class
function param_range = param_uncertainty(param_est, I_q_cur, B_cur, index_q, I_o_q_2_ori,...
                                         q_ori_ring_loc_unique_index, sz, len_t, d_input, q, ...
                                         model_name, estimation_method, M, num_iteration_max,...
                                         lower_bound, msd_fn, msd_grad_fn)

    
p = length(param_est) - 1;
q_lower = q - min(q);

if strcmp(model_name, 'user_defined')
    if isa(msd_grad_fn, 'function_handle')
        gr = @log_lik_grad;
    else
        gr = NaN;
    end
else
    gr = @log_lik_grad;
end

fun = @(param) neg_log_lik_with_grad(param, I_q_cur, NaN, index_q,...
                              I_o_q_2_ori, d_input, q_ori_ring_loc_unique_index,...
                              sz, len_t, q_lower, model_name,...
                              msd_fn, msd_grad_fn);
 
        options = optimoptions('fmincon','SpecifyObjectiveGradient',true);  
        options = optimoptions(options,'MaxIterations',num_iteration_max);
        options = optimoptions(options,'StepTolerance',10^(-6));
        options = optimoptions(options,'Display','off');
        options = optimoptions(options,'HessianApproximation','lbfgs');
        A = [];
        b = [];
        Aeq = [];
        beq = [];
        lb = lower_bound;
        ub = [];
        nonlcon = [];

        m_param_lower = fmincon(fun, param_est, A,b,Aeq,beq,lb,ub,nonlcon,options);

 q_upper = q + min(q);
 fun = @(param) neg_log_lik_with_grad(param, I_q_cur, NaN, index_q,...
                              I_o_q_2_ori, d_input, q_ori_ring_loc_unique_index,...
                              sz, len_t, q_upper, model_name,...
                              msd_fn, msd_grad_fn);
 
        options = optimoptions('fmincon','SpecifyObjectiveGradient',true);  
        options = optimoptions(options,'MaxIterations',num_iteration_max);
        options = optimoptions(options,'StepTolerance',10^(-6));
        options = optimoptions(options,'Display','off');
        options = optimoptions(options,'HessianApproximation','lbfgs');
        A = [];
        b = [];
        Aeq = [];
        beq = [];
        lb = lower_bound;
        ub = [];
        nonlcon = [];

        m_param_upper = fmincon(fun, param_est, A,b,Aeq,beq,lb,ub,nonlcon,options);

 param_range = zeros(2, p + 1);
 for i = 1:(p + 1)
    param_range(1, i) = min(m_param_lower(i), m_param_upper(i));
    param_range(2, i) = max(m_param_lower(i), m_param_upper(i));
 end

 %half_length_param_range_fft = (param_range(2, :) - param_range(1, :)) / 2;

 if strcmp(estimation_method, 'asymptotic')
    theta = exp(param_est(1:end-1));
    
    if isnan(B_cur)
        sigma_2_0_hat = exp(param_est(end));
        B_cur = 2 * sigma_2_0_hat;
    end

    A_cur = abs(2 * (I_o_q_2_ori - B_cur / 2));
    eta = B_cur / 4;

    MSD_list = get_MSD_with_grad(theta, d_input, model_name, msd_fn, msd_grad_fn);
    MSD = MSD_list.MSD;
    MSD_grad = MSD_list.MSD_grad;

    grad_trans = get_grad_trans(theta, d_input, model_name);
    Hessian_sum = zeros(p + 1);

    for i_q_selected = index_q
        q_selected = q(i_q_selected);
        sigma_2 = A_cur(i_q_selected) / 4;

        acf0 = sigma_2 * exp(-q_selected^2 * MSD / 4);
        acf = acf0;
        acf(1) = acf(1) + eta;
        acf = double(acf);
        acf_grad = zeros(len_t, p + 1);

        for i_p = 1:p
            acf_grad(:, i_p) = (-acf0 * q_selected^2 / 4).' .* (MSD_grad(:, i_p) * grad_trans(i_p));
        end

        acf_grad(:, p + 1) = -acf0 * 0.5 / sigma_2 * sign(I_o_q_2_ori(i_q_selected) - B_cur / 2);
        acf_grad(1, p + 1) = acf_grad(1, p + 1) + 0.5;
        acf_grad(:, p + 1) = acf_grad(:, p + 1) * sigma_2_0_hat;
  
        Hessian = zeros(p + 1);

        for i_p = 1:(p + 1)
            for j_p = 1:(p + 1)
                Hessian(i_p, j_p) = toeplitz_trace_hess(acf.', acf_grad(:, i_p).', acf_grad(:, j_p).');
            end
        end

        Hessian_sum = Hessian_sum + Hessian * length(q_ori_ring_loc_unique_index{i_q_selected});
    end

    Hessian_sum = Hessian_sum * M / sum(cellfun(@length, q_ori_ring_loc_unique_index(index_q)));

    if cond(Hessian_sum) > 1e10
        epsilon = 1e-6;
        Hessian_sum = Hessian_sum + epsilon * eye(size(Hessian_sum,2));
    end

    sd_theta_B = sqrt(diag(inv(Hessian_sum)));
    param_range(1, :) = param_range(1, :) - sd_theta_B' * norminv(0.975);
    param_range(2, :) = param_range(2, :) + sd_theta_B' * norminv(0.975);
    %half_length_param_range_est = sd_theta_B' * norminv(0.975);
end

end

