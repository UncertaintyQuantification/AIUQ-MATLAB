% Perform 2D fast Fourier transformation on SS_T matrix, record frame size for each frame, total number of frames, and sequence of lag times. 
% Calculate and record circular wave number for complete q ring.
% Input:
%    intensity: intensity profile, SS_T matrix
%    pxsz: size of one pixel in unit of micron
%    mindt: minimum lag time
% Output:
%    A list object containing transformed intensity profile in reciprocal space and corresponding parameters.
function ans_list = FFT2D(intensity, pxsz, mindt)
    sz = sqrt(size(intensity, 1));
    len_t = size(intensity, 2);
    I_q_matrix = NaN(sz^2, len_t);
    
    for i = 1:len_t
        I_q_matrix(:, i) = reshape(fft2(reshape(intensity(:, i), sz, sz)), [], 1);
    end
    
    ans_list = struct();
    ans_list.sz = sz;
    ans_list.len_q = length(1:((sz - 1) / 2));
    ans_list.len_t = len_t;
    ans_list.I_q_matrix = I_q_matrix;
    ans_list.q = (1:((sz - 1) / 2)) * 2 * pi / (sz * pxsz);
    ans_list.input = mindt * (1:len_t);
    ans_list.d_input = ans_list.input - ans_list.input(1);
end
