% Minimize l2 loss function for dynamic image structure function(Dqt), and return estimated param- eters and mean squared displacement(MSD).
% Input:
%    param: a vector of natural logarithm of parameters
%    A_ini: initial value of A(q) to be optimized over. Note true A(q) is determined by the properties of the imaged material and imaging optics.
%    q: wave vector in unit of um^-1
%    index_q: selected index of wave number
%    Dqt: observed dynamic image structure function.
%    d_input: sequence of lag times
%    model_name: model for constructing MSD, options from ('BM', 'OU','FBM', 'OU+FBM', 'user_defined')
%    msd_fn: user-defined mean squared displacement structure (MSD), a function of "param" parameters and "d_input" lag times
%    msd_grad_fn: user-defined MSD gradient structure, a function of "param" and "d_input" 
% Output:
%    A list of estimated parameters and MSD from minimizing the l2 loss function.

function ddm_result = theta_est_l2_dqt_estAB(param, A_ini, q, index_q, Dqt, d_input, model_name, msd_fn, msd_grad_fn)
    param_est_l2 = NaN(length(q), length(param)+1);

    for q_j = index_q
        param_start = [param, log(abs(A_ini(q_j)))];
        if q_j == length(q)
           param_start = [param, 0];
        end
     
        fun = @(param) l2_estAB(param, Dqt(q_j,:), q(q_j), d_input,... 
                                  model_name, msd_fn, msd_grad_fn);
 
        options = optimoptions('fmincon','GradConstr','off');  
        options = optimoptions(options,'GradObj','off');  
        options = optimoptions(options,'MaxIterations',100);
        options = optimoptions(options,'StepTolerance',10^(-6));
        options = optimoptions(options,'Display','off');
        options = optimoptions(options,'HessianApproximation','lbfgs');
        A = [];
        b = [];
        Aeq = [];
        beq = [];
        lb = [];
        ub = [];
        nonlcon = [];

        param_est_l2(q_j, :) = fmincon(fun, param_start, A,b,Aeq,beq,lb,ub,nonlcon,options);
    end

    param_ddm_mat = zeros(length(q), length(param)-1);

    for i = 1:size(param_est_l2, 1)
        params = exp(param_est_l2(i,1:end-1));
        param_ddm_mat(i,:) = get_est_param(params, model_name);
    end
 
    param_ddm = mean(param_ddm_mat, 'omitnan');
    
    msd_ddm = get_MSD(param_ddm, d_input, model_name, msd_fn);
    
    ddm_result.param_est = param_ddm;
    ddm_result.msd_est = msd_ddm;
    ddm_result.sigma_2_0_est = mean(exp(param_est_l2(:,end-1)), 'omitnan');
    ddm_result.A_est = exp(param_est_l2(:,end)); 

end

