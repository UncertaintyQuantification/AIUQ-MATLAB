% Construct parameter transformation for parameters to be optimized over in AIUQ method of SAM class
% Input:
%     theta: parameters to be optimized over
%     d_input: sequence of lag times
%     model_name: for the fitted model, options from ("BM", "OU", "FBM", "OU+FBM", "user_defined")
% Output:
%     A vector of transformed parameters to be optimized over in AIUQ method of SAM class
function grad_trans = get_grad_trans(theta, d_input, model_name)
    if strcmp(model_name, 'BM')
        grad_trans = theta(1);
    elseif strcmp(model_name, 'FBM')
        beta = theta(1);
        alpha = 2 * theta(2) / (1 + theta(2));
        grad_trans = [beta, alpha * (1 - alpha/2)];
    elseif strcmp(model_name, 'OU')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        grad_trans = [rho * (1 - rho), amplitude];
    elseif strcmp(model_name, 'OU+FBM')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        beta = theta(3);
        alpha = 2 * theta(4) / (1 + theta(4));
        grad_trans = [rho*(1 - rho), amplitude, beta, alpha*(1 - alpha/2)];
    elseif strcmp(model_name, 'BM_anisotropic')
        grad_trans = theta(1:2);
    elseif strcmp(model_name, 'FBM_anisotropic')
        beta_x = theta(1);
        alpha_x = 2 * theta(2) / (1 + theta(2));
        beta_y = theta(3);
        alpha_y = 2 * theta(4) / (1 + theta(4));
        grad_trans = [beta_x, alpha_x*(1 - alpha_x/2), beta_y, alpha_y*(1 - alpha_y/2)];
    elseif strcmp(model_name, 'OU+BM_anisotropic')
        rho_x = theta(1) / (1 + theta(1));
        amplitude_x = theta(2);
        beta_x = theta(3);
        rho_y = theta(4) / (1 + theta(4));
        amplitude_y = theta(5);
        beta_y = theta(6);
        grad_trans = [rho_x*(1 - rho_x), amplitude_x, beta_x, rho_y*(1 - rho_y), amplitude_y, beta_y];
    elseif strcmp(model_name, 'OU+FBM_anisotropic')
        rho_x = theta(1) / (1 + theta(1));
        amplitude_x = theta(2);
        beta_x = theta(3);
        alpha_x = 2 * theta(4) / (1 + theta(4));
        rho_y = theta(5) / (1 + theta(5));
        amplitude_y = theta(6);
        beta_y = theta(7);
        alpha_y = 2 * theta(8) / (1 + theta(8));
        grad_trans = [rho_x*(1 - rho_x), amplitude_x, beta_x, alpha_x*(1 - alpha_x/2),...
                      rho_y*(1 - rho_y), amplitude_y, beta_y, alpha_y*(1 - alpha_y/2)];
    elseif strcmp(model_name, 'user_defined')
        grad_trans = theta;
    end
end
