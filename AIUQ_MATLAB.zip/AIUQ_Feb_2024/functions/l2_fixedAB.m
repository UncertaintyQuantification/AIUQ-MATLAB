% Compute l2 loss for dynamic image structure function(Dqt) using A(q) and B are both estimated within the model.
% Input: 
%    param: a vector of natural logarithm of parameters
%    Dqt_cur: observed dynamic image structure function (Dqt) that  can be obtained from ensemble average of absolute values squared of Fourier transformed intensity difference
%    q_cur: wave vector in unit of um^-1
%    A_est_q_cur: estimated value of A(q). This parameter is determined by the properties of the imaged material and imaging optics. 
%    B_est: estimated value of B. This parameter is determined by the noise in the system.
%    d_input: sequence of lag times
%    model_name: model name for the process, options from ("BM","OU","FBM","OU+FBM","user_defined")
%  Users can definve their own MSD expressions by specifying
%    msd_fn: user defined MSD structure, a function of theta and d_input
%    msd_grad_fn: user defined MSD gradient structure, a function of theta and d_input
% Output:
%    Squared differences between the true Dqt and the predicted Dqt.
function l2_fixedAB = l2_fixedAB(param, Dqt_cur, q_cur, A_est_q_cur, B_est, d_input, model_name,...
                                 msd_fn, msd_grad_fn)
  
    theta = exp(param);
  
    msd_list = get_MSD_with_grad(theta, d_input(2:end), model_name, msd_fn, msd_grad_fn);
    MSD = msd_list.MSD;
    
    l2_fixedAB = sum((Dqt_cur - (A_est_q_cur* (1 - exp((-q_cur.^2).* MSD / 4)) + B_est)).^2);
end
