% Compute l2 loss for dynamic image structure function(Dqt) using A(q) and B are both estimated within the model.
% Input: 
%    param: a vector of natural logarithm of parameters
%    Dqt_cur: observed dynamic image structure function (Dqt) that  can be obtained from ensemble average of absolute values squared of Fourier transformed intensity difference
%    q_cur: wave vector in unit of um^-1
%    d_input: sequence of lag times
%    model_name: model name for the process, options from ("BM","OU","FBM","OU+FBM","user_defined")
%  Users can definve their own MSD expressions by specifying
%    msd_fn: user defined MSD structure, a function of theta and d_input
%    msd_grad_fn: user defined MSD gradient structure, a function of theta and d_input
% Output:
%    Squared differences between the true Dqt and the predicted Dqt.
function l2_estAB = l2_estAB(param, Dqt_cur, q_cur, d_input, model_name, msd_fn, msd_grad_fn)
  
    theta = exp(param);
    A_cur = theta(end);
    B_cur = theta(end-1);
    theta_msd = theta(1:(end-2));
    
    msd_list = get_MSD_with_grad(theta_msd, d_input(2:end), model_name, msd_fn, msd_grad_fn);
    msd = msd_list.MSD;
    
    l2_estAB = sum((Dqt_cur - (A_cur * (1 - exp((-q_cur.^2).* msd / 4)) + B_cur)).^2);
end
