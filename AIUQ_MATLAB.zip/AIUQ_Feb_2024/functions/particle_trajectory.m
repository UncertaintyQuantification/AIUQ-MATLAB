function particle_trajectory(pos, N, len, frame_size, SP, maintitle)
    
    traj1 = pos(1:N:end, :);
    
    figure('Position', [500 500 450 320]);
    plot(traj1.x, traj1.y,'k', 'LineWidth', 1);
    xlim([0 frame_size]);
    ylim([0 frame_size]);
    xlabel('Frame size');
    ylabel('Frame size');
    title(maintitle);
        
    hold on;
    for i = 2:N
        v = pos(i:N:end, :);
        hold on;
        plot(v.x, v.y, 'k', 'Color', rand(1, 3), 'LineWidth', 1);
    end
    
end
