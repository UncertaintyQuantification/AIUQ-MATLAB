% Construct estimated mean squared displacement (MSD) for a given stochastic process.
% Input: a struct variable that contains:
%    theta: parameters in MSD function
%    d_input: sequence of lag times
%    model_name: model name for the process, options from ("BM","OU","FBM","OU+FBM","user_defined")
%    msd_fn: user defined mean squared displacement structure (MSD), a function of param parameters and d_input lag times
% Output:
%    A vector of MSD values for a given sequence of lag times.
function MSD = get_MSD(theta, d_input, model_name, msd_fn)

%     if(~isfield(msd, "theta") && isfield(msd, 'msd_fn'))
%         error("Please input parameters theta")
%     else
%         theta = msd.theta;
%     end
% 
%     if(~isfield(msd, "d_input") && isfield(msd, 'msd_fn'))
%         error("Please input the sequence of lag times")
%     else
%         d_input = msd.d_input;
%     end
% 
%     if(~isfield(msd, "model_name") && isfield(msd, 'msd_fn'))
%         error("Please input model name")
%     else
%         model_name = msd.model_name;
%     end

%     if(isfield(msd, 'msd_fn') && ~isa(msd.msd_fn, 'function_handle'))
%         error("Please input a valid function for computing MSD")
%     end

%     if(isfield(msd, 'msd_fn') && ~isfield(msd, 'msd_grad_fn'))
%         error("Please also input a function for computing the gradients of MSD")
%     end

%     if(isfield(msd, 'msd_fn') && isfield(msd, 'msd_grad_fn'))
%         MSD_with_grad.MSD = msd.msd_fn(theta, d_input);
%         MSD_with_grad.MSD_grad = msd.msd_grad_fn(theta, d_input);
     if strcmp(model_name, 'user_defined')
        MSD = msd_fn(theta, d_input);
     elseif strcmp(model_name, 'BM')
        beta = theta(1);
        MSD = beta * d_input;
     elseif strcmp(model_name, 'FBM')
        beta = theta(1);
        alpha = theta(2); 
        MSD = beta * d_input.^alpha;
     elseif strcmp(model_name, 'OU')
        rho = theta(1);
        amplitude = theta(2);
        MSD = amplitude * (1 - rho.^d_input);
     elseif strcmp(model_name, 'OU+FBM')
        rho = theta(1);
        amplitude = theta(2);
        beta = theta(3);
        alpha = theta(4); 
        MSD = beta * d_input.^alpha + amplitude * (1 - rho.^d_input);
    end
end
