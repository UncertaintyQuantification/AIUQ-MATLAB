% Compute dynamic image structure function(Dqt) using Fourier transformed intensity profile and a selection of wave number(q) range.
% Input:
%     len_q: number of wave number
%     index_q: a vector of selected wave number index 
%     len_t: number of time steps
%     I_q_matrix: intensity profile in reciprocal space (after Fourier transformation)
%     q_ori_ring_loc_unique_index: index for wave vector that gives unique frequency 
%     sz: frame size of intensity profile
% Output:
%     Dynamic image structure function(Dqt) can be obtained from ensemble average of absolute values squared of Four transformed intensity difference
function Dqt = get_Dqt(len_q, index_q, len_t, I_q_matrix, q_ori_ring_loc_unique_index, sz)
    Dqt = NaN(len_q, len_t - 1);

    for q_j = index_q
        I_q_cur = I_q_matrix(q_ori_ring_loc_unique_index{q_j}, :);
        
        for t_i = 1:(len_t - 1)
            diff_matrix = abs(I_q_cur(:, (t_i + 1):len_t) - I_q_cur(:, 1:(len_t - t_i)));
            Dqt(q_j, t_i) = mean((diff_matrix.^2) / (sz^2), 'all', 'omitnan');
        end
    end
end
