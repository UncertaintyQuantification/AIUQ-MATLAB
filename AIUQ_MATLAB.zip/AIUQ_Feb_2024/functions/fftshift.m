% Rearranges a 2D Fourier transform x by shifting the zero-frequency component to the center of the matrix.
% Input:
%    x: square matrix input with odd number of rows and columns
%    dim: shift method. By default, dim=-1, swaps the first quadrant of x with the third, and the second quadrant with the fourth. 
%         If dim=1, swaps rows 1 to middle with rows (middle+1) to end. 
%         If dim=2, swaps columns 1 to middle with columns (middle+1) to end. If dim=3, reverse fftshift.
% Output:
%    The shifted matrix.
function output_matrix = fftshift(input_matrix, dim)
    [rows, cols] = size(input_matrix);

    swap_up_down = @(matrix) [matrix((ceil(rows/2)+1):end, :); matrix(1:ceil(rows/2), :)];

    swap_left_right = @(matrix) [matrix(:, (ceil(cols/2)+1):end), matrix(:, 1:ceil(cols/2))];

    swap_up_down_reverse = @(matrix) [matrix(ceil(rows/2):end, :); matrix(1:(ceil(rows/2)-1), :)];

    swap_left_right_reverse = @(matrix) [matrix(:, ceil(cols/2):end), matrix(:, 1:(ceil(cols/2)-1))];

    if dim == -1
        input_matrix = swap_up_down(input_matrix);
        output_matrix = swap_left_right(input_matrix);
    elseif dim == 1
        output_matrix = swap_up_down(input_matrix);
    elseif dim == 2
        output_matrix = swap_left_right(input_matrix);
    elseif dim == 3
        input_matrix = swap_up_down_reverse(input_matrix);
        output_matrix = swap_left_right_reverse(input_matrix);
    else
        error('Invalid dimension parameter');
    end
end
