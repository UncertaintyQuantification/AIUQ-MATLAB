% Construct intensity profile with structure ’T_SS_mat’ for a given particle trajectory, background intensity profile, and user defined radius of particle.
% Input:
%      len_t: number of time steps
%      M: number of particles
%      I: background intensity profile. Should has structure T_SS_mat and be a matrix with dimension len_t by sz×sz.
%      pos: position matrix with dimension M×len_t for particle trajectory
%      Ic: vector of maximum intensity of each particle 
%      sz: frame size of simulated square image 
%      sigma_p: radius of the spherical particle (3xsigma_p)
% Output:
%      Intensity profile matrix with structure "T_SS_mat" (matrix with dimension len_t by sz×sz). 
function I = fill_intensity(len_t, M, I, pos, Ic, sz, sigma_p)
    for i = 1:len_t
        for j = 1:M
            xp = pos(j + M * (i - 1), 1);
            yp = pos(j + M * (i - 1), 2);
            x_range = floor(xp - 3 * sigma_p):ceil(xp + 3 * sigma_p);
            y_range = floor(yp - 3 * sigma_p):ceil(yp + 3 * sigma_p);
            x = repmat(x_range, 1, length(x_range));
            y = repelem(y_range, 1, length(x_range));
            dist_2 = (x - xp).^2 + (y - yp).^2;
            binary_result = (dist_2 <= ((3 * sigma_p)^2));
            Ip = Ic(j) * exp(-dist_2 / (2 * sigma_p^2));
            x_fill = x(binary_result);
            y_fill = y(binary_result);
            index_fill = x_fill + sz * (y_fill - 1);
            Ip_fill = Ip(binary_result);

            legitimate_index = (index_fill > 0) & (index_fill < (sz * sz));
            if any(legitimate_index)
                I(i, index_fill(legitimate_index)) = I(i, index_fill(legitimate_index)) + Ip_fill(legitimate_index);
            end
        end
    end
end