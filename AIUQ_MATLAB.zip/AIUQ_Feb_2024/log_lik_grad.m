% This function computes the gradient for natural logarithm of the likelihood for selected range of wave vectors
% Input:
%   param: a vector of natural logarithm of parameters
%   I_q_cur: Fourier transformed intensity profile
%   B_cur: current value of B. This parameter is determined by the noise in the system. 
%   index_q: selected index of wave number
%   I_o_q_2_ori: absolute square of Fourier transformed intensity profile,en semble over time
%   d_input: sequence of lag times
%   q_ori_ring_loc_unique_index: index for wave vector that gives a unique frequency
%   sz: frame size of the intensity profile
%   len_t: number of time steps
%   q: wave vector in units of um^-1
%   model_name: model for constructing MSD, options from ('BM', 'OU','FBM', 'OU+FBM', 'user_defined')
%   msd_fn: user-defined mean squared displacement structure (MSD), a function of "param" parameters and "d_input" lag times
%   msd_grad_fn: user-defined MSD gradient structure, a function of "param" and "d_input" 
% Output:
%   The numerical value of gradient for natural logarithm of the likelihood.
function grad = log_lik_grad(param, I_q_cur, B_cur, index_q, I_o_q_2_ori, d_input, q_ori_ring_loc_unique_index, sz,...
                                      len_t, q, model_name,...
                                      msd_fn, msd_grad_fn)

    p = length(param) - 1;
    theta = exp(param(1:p));
    
    if isnan(B_cur)
        sigma_2_0_hat = exp(param(p + 1));
        B_cur = 2 * sigma_2_0_hat;
    end

    A_cur = abs(2 * (I_o_q_2_ori - B_cur / 2));
 
%     msd.theta = theta;
%     msd.d_input = d_input;
%     msd.model_name = model_name;
%     if(isa(msd_fn, 'function_handle'))
%         msd.msd_fn = msd_fn;
%         msd.msd_grad_fn = msd_grad_fn;
%     end
% 
%     MSD_list = Get_MSD_with_grad(msd);
    MSD_list = get_MSD_with_grad(theta,d_input,model_name, msd_fn,msd_grad_fn);
    MSD = MSD_list.MSD;
    MSD_grad = MSD_list.MSD_grad;
    % Then compute the gradients of original parameters w.r.t the
    % transformed parameters:
    grad_trans = get_grad_trans(theta,d_input,model_name);

    eta=B_cur/4;
    grad = zeros(1, p+1);
    quad_terms = zeros(1, p+1);
    trace_terms = zeros(1, p+1);

    for i_q_selected = index_q
        output_re = real(I_q_cur(q_ori_ring_loc_unique_index{i_q_selected}, :)) / sz;
        output_im = imag(I_q_cur(q_ori_ring_loc_unique_index{i_q_selected}, :)) / sz;
    
        n_q = length(q_ori_ring_loc_unique_index{i_q_selected});
        q_selected = q(i_q_selected);
        sigma_2 = max(A_cur(i_q_selected)/4, 0.0001); % sometimes this is 0?
    
        acf0 = sigma_2 * exp(-q_selected^2 * MSD / 4);
        acf = acf0;
        acf(1) = acf(1) + eta;
   
        tilde_Sigma_inv_output_re = toeplitz_solve(acf, output_re.');
        tilde_Sigma_inv_output_im = toeplitz_solve(acf, output_im.');
    
        acf_grad = nan(len_t, p+1);

    for i_p = 1:p
        acf_grad(:, i_p) = -acf0 * q_selected^2 / 4 .* MSD_grad(:,i_p).' * grad_trans(i_p);
           
        Q_tilde_Sigma_inv_output_re = toeplitz_prod(acf_grad(:, i_p), tilde_Sigma_inv_output_re);
        Q_tilde_Sigma_inv_output_im = toeplitz_prod(acf_grad(:, i_p), tilde_Sigma_inv_output_im);
        
        quad_terms(i_p) = quad_terms(i_p) + sum(tilde_Sigma_inv_output_re.* Q_tilde_Sigma_inv_output_re, "all");
        quad_terms(i_p) = quad_terms(i_p) + sum(tilde_Sigma_inv_output_im.* Q_tilde_Sigma_inv_output_im, "all");
        
        trace_terms(i_p) = trace_terms(i_p) + n_q * toeplitz_trace_grad(acf.', acf_grad(:, i_p).');
    end
    
    acf_grad(:, p+1) = -acf0 * 0.5 / sigma_2 * sign(I_o_q_2_ori(i_q_selected) - B_cur/2);
    acf_grad(1, p+1) = acf_grad(1, p+1) + 0.5;
    acf_grad(:, p+1) = acf_grad(:, p+1) * sigma_2_0_hat;
  
    Q_tilde_Sigma_inv_output_re = toeplitz_prod(acf_grad(:, p+1),tilde_Sigma_inv_output_re);
    Q_tilde_Sigma_inv_output_im = toeplitz_prod(acf_grad(:, p+1),tilde_Sigma_inv_output_im);
   
    quad_terms(p+1) = quad_terms(p+1) + sum(tilde_Sigma_inv_output_re.* Q_tilde_Sigma_inv_output_re, "all");
    quad_terms(p+1) = quad_terms(p+1) + sum(tilde_Sigma_inv_output_im.* Q_tilde_Sigma_inv_output_im, "all");
    
    trace_terms(p+1) = trace_terms(p+1) + n_q * toeplitz_trace_grad(acf, acf_grad(:, p+1));
    end

    grad = -(-trace_terms + 0.5 * quad_terms);
  
end
