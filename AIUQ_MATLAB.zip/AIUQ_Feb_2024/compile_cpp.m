% This file is written to compile all required C++ functions implemented in
% this Matlab package. Please execute it at your first time using the
% package. The code here only need to be ran once.

addpath('functions/');
addpath('header/');
addpath('Eigen/');

 mex -I/usr/local/include -L/usr/local/Cellar/fftw_x86_64/lib -lfftw3 log_density.cpp -output log_density
 mex -I/usr/local/include -L/usr/local/Cellar/fftw_x86_64/lib -lfftw3 toeplitz_prod.cpp -output toeplitz_prod 
 mex -I/usr/local/include -L/usr/local/Cellar/fftw_x86_64/lib -lfftw3 toeplitz_solve.cpp -output toeplitz_solve 
 mex -I/usr/local/include -L/usr/local/Cellar/fftw_x86_64/lib -lfftw3 phi_log_det.cpp -output phi_log_det
 mex -I/usr/local/include -L/usr/local/Cellar/fftw_x86_64/lib -lfftw3 toeplitz_trace_grad.cpp -output toeplitz_trace_grad
 mex -I/usr/local/include -L/usr/local/Cellar/fftw_x86_64/lib -lfftw3 toeplitz_trace_hess.cpp -output toeplitz_trace_hess
