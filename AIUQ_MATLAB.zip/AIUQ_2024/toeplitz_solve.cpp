#include <vector>
#include <cmath>
#include <complex>
#include <iostream>
#include <fftw3.h>
#include "mex.h"
#include "header/GSchur.h"
#include "header/Toeplitz.h"
#include "header/NormalToeplitz.h"

// This function computes Tz^{-1} * z where Tz is symmetric Toeplitz matrix.

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs != 2) {
        mexErrMsgIdAndTxt("InvalidInput", "Two input arguments required.");
    }

    // Get input data from MATLAB
    const double *acf = mxGetPr(prhs[0]);
    const double *x = mxGetPr(prhs[1]);
    int n = mxGetNumberOfElements(prhs[0]);
    int m = mxGetN(prhs[1]);
    int numRowsX = mxGetM(prhs[1]);

    // Create a Toeplitz structure
    Toeplitz Tz(n);
    Tz.set_acf(acf);

    // Prepare the output matrix with m columns
    plhs[0] = mxCreateDoubleMatrix(n, m, mxREAL);
    double *Y = mxGetPr(plhs[0]);

    for (int col = 0; col < m; col++) {
        Tz.solve(Y + col * n, x + col * numRowsX); 
    }
}
