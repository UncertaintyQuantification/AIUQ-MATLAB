#include <vector>
#include <cmath>
#include <complex>
#include <iostream>
#include <fftw3.h>
#include "mex.h"
#include "header/GSchur.h"

// This function compute the first column/row of Tz^{-1} and log(det(Tz))

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    if (nrhs != 1) {
        mexErrMsgIdAndTxt("MATLAB:computeDeltaAndLdV:nargin", "Expected 1 input argument.");
    }
    if (mxGetClassID(prhs[0]) != mxDOUBLE_CLASS || mxIsComplex(prhs[0])) {
        mexErrMsgIdAndTxt("MATLAB:computeDeltaAndLdV:inputNotRealDouble", "Input must be a noncomplex double vector.");
    }

    // Get input ACF vector
    double* acf = mxGetPr(prhs[0]);
    int n = mxGetNumberOfElements(prhs[0]);

    // Call C++ function to compute delta and ldV
    double delta[n], ldV;
    GSchurN gs(n, 64);
    gs.compute(delta, ldV, acf);

    // Create output arrays
    plhs[0] = mxCreateDoubleMatrix(1, n, mxREAL);
    plhs[1] = mxCreateDoubleScalar(ldV);
    double* outDelta = mxGetPr(plhs[0]);

    // Copy results to output arrays
    for (int i = 0; i < n; i++) {
        outDelta[i] = delta[i];
    }
}

