% Construct correlation matrix for fractional Brownian motion.
% Input:
%      len_t: number of time steps
%      H: Hurst parameter, value between 0 and 1
% Output:
%      Correlation matrix with dimension len_t-1 by len_t-1.
function cov = corr_fBM(len_t, H) 
    cov = zeros(len_t-1, len_t-1);
    for i = 0:(len_t-2)
        cov(i+1,:) = 0.5*(abs(i-(0:(len_t-2))+1).^(2*H))+0.5*(abs(1-i+(0:(len_t-2))).^(2*H))-abs(i-(0:(len_t-2))).^(2*H);
    end
end    