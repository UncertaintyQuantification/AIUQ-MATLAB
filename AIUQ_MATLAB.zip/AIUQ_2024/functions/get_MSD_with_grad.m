% Construct mean squared displacement (MSD) and its gradient for a given stochastic process or a user defined MSD and gradient structure.
% Input: 
%    theta: transformed parameters in MSD function for MLE estimation
%    d_input: sequence of lag times
%    model_name: model name for the process, options from ("BM","OU","FBM","OU+FBM","user_defined")
%  Users can definve their own MSD expressions by specifying
%    msd_fn: user defined MSD structure, a function of theta and d_input
%    msd_grad_fn: user defined MSD gradient structure, a function of theta and d_input
% Output:
%    A list of two variables, MSD and MSD gradient.
function MSD_with_grad = get_MSD_with_grad(theta, d_input, model_name, msd_fn, msd_grad_fn)
                                           
    MSD_with_grad = struct();  
%     if(~isfield(msd, "theta") && isfield(msd, 'msd_fn'))
%         error("Please input parameters")
%     else
%         theta = msd.theta;
%     end
% 
%     if(~isfield(msd, "d_input") && isfield(msd, 'msd_fn'))
%         error("Please input d_input")
%     else
%         d_input = msd.d_input;
%     end
% 
%     if(~isfield(msd, "model_name") && isfield(msd, 'msd_fn'))
%         error("Please input model name")
%     else
%         model_name = msd.model_name;
%     end
% 
%     if(isfield(msd, 'msd_fn') && ~isa(msd.msd_fn, 'function_handle'))
%         error("Please input a valid function for computing MSD")
%     end

%     if(isfield(msd, 'msd_fn') && ~isfield(msd, 'msd_grad_fn'))
%         error("Please also input a function for computing the gradients of MSD")
%     end

%     if(isfield(msd, 'msd_fn') && ~isfield(msd, 'msd_grad_fn'))
%         MSD_with_grad.MSD = msd.msd_fn(theta, d_input);
%         MSD_with_grad.MSD_grad = NaN;
%     end
% 
%     if(isfield(msd, 'msd_fn') && isfield(msd, 'msd_grad_fn'))
%         MSD_with_grad.MSD = msd.msd_fn(theta, d_input);
%         MSD_with_grad.MSD_grad = msd.msd_grad_fn(theta, d_input);

    if nargin < 4
        msd_fn = NaN;
    end

    if nargin < 5
        msd_grad_fn = NaN;
    end

    if (isa(msd_fn, 'function_handle') && ~isa(msd_grad_fn, 'function_handle'))
        if ~isa(msd_fn, 'function_handle')
            error("Please input a valid function for computing MSD")
        else
            MSD_with_grad.MSD = msd_fn(theta, d_input);
            MSD_with_grad.MSD_grad = NaN;
        end
    end

    if (isa(msd_fn, 'function_handle') && isa(msd_grad_fn, 'function_handle'))
        MSD_with_grad.MSD = msd_fn(theta, d_input);
        MSD_with_grad.MSD_grad = msd_grad_fn(theta, d_input);

    elseif strcmp(model_name, 'BM')||strcmp(model_name, 'BM_anisotropic')
        beta = theta(1);
        MSD_with_grad.MSD = beta * d_input;
        MSD_with_grad.MSD_grad = d_input.';
     elseif strcmp(model_name, 'FBM')||strcmp(model_name, 'FBM_anisotropic')
        beta = theta(1);
        alpha = 2 * theta(2) / (1 + theta(2)); 
        MSD_with_grad.MSD = beta * d_input.^alpha;
        MSD_grad_1 = d_input.^alpha;
        MSD_grad_2 = beta * [0, log(d_input(2:end))] .* (d_input.^alpha);
        MSD_with_grad.MSD_grad = [MSD_grad_1.', MSD_grad_2.'];
     elseif strcmp(model_name, 'OU')||strcmp(model_name, 'OU_anisotropic')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        MSD_with_grad.MSD = amplitude * (1 - rho.^d_input);
        MSD_grad_1 = -amplitude * d_input .* (rho.^ (d_input - 1));
        MSD_grad_2 = 1-(rho.^d_input);
        MSD_with_grad.MSD_grad = [MSD_grad_1.', MSD_grad_2.'];
     elseif strcmp(model_name, 'OU+FBM')||strcmp(model_name, 'OU+FBM_anisotropic')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        beta = theta(3);
        alpha = 2 * theta(4) / (1 + theta(4)); 
        MSD_with_grad.MSD = beta * d_input.^alpha + amplitude * (1 - rho.^d_input);
        MSD_grad_1 = -amplitude * d_input .* (rho.^ (d_input - 1));
        MSD_grad_2 = 1-(rho.^d_input);
        MSD_grad_3 = d_input.^alpha;
        MSD_grad_4 = beta * [0, log(d_input(2:end))] .* (d_input.^alpha);
        MSD_with_grad.MSD_grad = [MSD_grad_1.', MSD_grad_2.', MSD_grad_3.', MSD_grad_4.'];
    end
end
