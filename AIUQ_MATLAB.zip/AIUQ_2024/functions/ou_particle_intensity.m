% The function simulates 2D particle trajectory follows Ornstein–Uhlenbeck process(OU) for M particles.
% Input:
%      pos0: initial position for M particles, matrix with dimension M by 2
%      M: number of particles
%      len_t: number of time steps
%      mu: mean velocity of the drift
%      sigma: distance moved per time step
%      rho: correlation between successive step and previous step, value between 0 and 1
% Output:
%      Position matrix with dimension M×len_t by 2 for particle trajectory. The first M rows being the initial position pos0.
function pos = ou_particle_intensity(pos0, M, len_t, mu, sigma, rho)

%     if drift_dir == 0
         pos = zeros(M*len_t, 2);
         pos(1:M, :) = pos0 + randn(M, 2) * sigma;
         sd_innovation_OU = sqrt(sigma^2 * (1 - rho^2));
         
         for i = 1:(len_t-1)
             innovation = randn(M, 2) * sd_innovation_OU;
             pos(i*M + (1:M), :) = rho * (pos((i-1)*M + (1:M), :) - pos0 - (i-1) * mu) + ...
                                   (i-1) * mu + pos0 + innovation;
         end
%     elseif drift_dir == 1
%         theta = 2 * pi * rand(M, 1);
%         pos = zeros(M*len_t, 2);
%         pos(1:N, :) = pos0 + randn(N, 2) * sigma;
%         sd_innovation_OU = sqrt(sigma^2 * (1 - rho^2));
%         
%         for i = 1:(len-1)
%             innovation = randn(N, 2) * sd_innovation_OU;
%             pos(i*N + (1:N), 1) = rho * (pos((i-1)*N + (1:N), 1) - pos0(1) - (i-1) * mu * cos(theta)) +...
%                                   (i-1) * mu * cos(theta) + pos0(1) + innovation(:, 1);
%             pos(i*N + (1:N), 2) = rho * (pos((i-1)*N + (1:N), 1) - pos0(1) - (i-1) * mu * sin(theta)) +...
%                 (i-1) * mu * sin(theta) + pos0(2) + innovation(:, 2);
%         end
%    end
end