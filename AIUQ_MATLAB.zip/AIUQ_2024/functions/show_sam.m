% Function to print the SAM struct after the SAM model has been constructed.
% Input:
%    object: a struct from "SAM"
% Output:
%    Show a list of important parameters from "SAM"
function show_sim(object)
    fprintf('Fitted model: %s\n', object.user_model_name);
    fprintf('Number of q ring: %d\n', object.len_q);
    fprintf('Index of wave number selected: %s\n', mat2str(object.index_q));
    fprintf('True parameters in the model: %s\n', mat2str(object.param_truth));
    fprintf('Estimated parameters in the model: %s\n', mat2str(object.param_est));
    fprintf('True variance of background noise: %f\n', object.sigma_2_0_truth);
    fprintf('Estimated variance of background noise: %f\n', object.sigma_2_0_est);
    
    if strcmp(object.method, 'AIUQ')
        fprintf('Maximum log likelihood value: %f\n', object.mle);
        fprintf('Akaike information criterion score: %f\n', object.AIC);
    end
end
