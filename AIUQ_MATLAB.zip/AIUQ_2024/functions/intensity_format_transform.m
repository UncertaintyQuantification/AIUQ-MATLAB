% Transform intensity profile with different formats, ("SST_array", "S_ST_mat", "T_SS_mat"), space by space by time array, space by (space by time) matrix, or time by (space by space) matrix, 
% into SS_T matrix. In addition, crop each frame into a square image with odd frame size.
% Input:
%    intensity: intensity profile, array or matrix
%    intensity_str: structure of the original intensity profile, options from ("SST_array", "S_ST_mat", "T_SS_mat")
% Output:
%    A matrix of transformed intensity profile.

function intensity_transform = intensity_format_transform(intensity, intensity_str)
    if strcmp(intensity_str, 'SST_array')  % Two space indices and one time index, tiff
        if mod(size(intensity, 1), 2) == 0
            sz = min([size(intensity, 1), size(intensity, 2)])- 1;  % Pixel dimension; total # of pixels in each image = sz^2
        else
            sz = min([size(intensity, 1), size(intensity, 2)]);
        end
        len_t = size(intensity, 3);
        
        intensity_transform = NaN(sz^2, len_t);
        for i = 1:len_t
            % Convert the table to an array and then reshape
            %intensity_array = table2array(intensity(1:sz, 1:sz, i));
            %intensity_transform(:, i) = reshape(intensity_array(1:sz, 1:sz), [], 1);
            intensity_transform(:, i) = reshape(intensity(1:sz, 1:sz, i), [], 1);
        end
    elseif strcmp(intensity_str, 'S_ST_mat') 
        if mod(size(intensity, 1), 2) == 0
            sz = size(intensity, 1) - 1;  
        else
            sz = size(intensity, 1);
        end
        len_t = size(intensity, 2) / size(intensity, 1); 
        intensity_transform = NaN(sz^2, len_t);
        for i = 1:len_t
            % Convert the table to an array and then reshape
            %intensity_array = table2array(intensity(:, (1 + (sz + 1) * (i - 1)):sz + (sz + 1) * (i - 1)));
            %intensity_transform(:, i) = reshape(intensity_array(1:sz, 1:sz), [], 1);
            intensity_transform(:, i) = reshape(intensity(:, (1 + (sz + 1) * (i - 1)):sz + (sz + 1) * (i - 1)), [], 1);
        end
    elseif strcmp(intensity_str, 'T_SS_mat')  % Simulation for R, square matrix
        if mod(sqrt(size(intensity, 2)), 2) == 0
            sz = sqrt(size(intensity, 2)) - 1;  % Pixel dimension; total # of pixels in each image = sz^2
        else
            sz = sqrt(size(intensity, 2));
        end
        len_t = size(intensity, 1);
        intensity_transform = NaN(sz^2, len_t);
        for i = 1:len_t
            %%% Convert the table to an array and then reshape
            %intensity_array = table2array(intensity(i, :));
            %intensity_matrix = reshape(intensity_array, sz + 1, sz + 1);
            intensity_matrix = reshape(intensity(i, :), sz + 1, sz + 1);
            intensity_transform(:, i) = reshape(intensity_matrix(1:sz, 1:sz), [], 1);
        end
    else
        error('Invalid intensity_str');
    end
end
