% Compute numerical mean squared displacement(MSD) based on particle trajectory.
% Input:
%    pos: position matrix (with dimension M×len_t by 2) for particle trajectory. 
%    M: number of particles
%    len_t number of time steps
% Output:
%    A vector of numerical MSD for given lag times.
function num_msd_mean = numerical_msd(pos, M, len_t)
    pos_msd = reshape(pos, [M, len_t, 2]);
    msd_i = NaN(M, len_t-1);
    for dt = 1:(len_t-1)
        ndt = len_t - dt;
        xdiff = pos_msd(:, 1:ndt, 1) - pos_msd(:, (1+dt):(ndt+dt), 1);
        ydiff = pos_msd(:, 1:ndt, 2) - pos_msd(:, (1+dt):(ndt+dt), 2);
        mean_square = xdiff.^2 + ydiff.^2;
        if size(mean_square, 1) > 1
            msd_i(:, dt) = mean(mean_square, 2, 'omitnan');
        else
            msd_i(:, dt) = mean_square;
        end
    end
    
    num_msd_mean = mean(msd_i, 1, 'omitnan');
end
