% The function simulates 2D particle trajectory follows Brownian Motion (BM) for M particles.
% Input:
%      pos0: initial position for M particles, matrix with dimension M by 2
%      M: number of particles
%      len_t: number of time steps
%      mu: mean velocity of the drift
%      sigma: distance moved per time step
% Output:
%      Position matrix with dimension M×len_t by 2 for particle trajectory. The first M rows being the initial position pos0.
function pos = bm_particle_intensity(pos0, M, len, mu, sigma)
    pos = zeros(M*len, 2);
    pos(1:M, :) = pos0;
    for i = 1:(len-1)
        pos(i*M + (1:M), :) = pos((i-1)*M + (1:M), :) + randn(M, 2) * sigma + mu;
    end
end
