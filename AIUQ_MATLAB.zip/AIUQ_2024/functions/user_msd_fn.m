% This is a simple function to test that SAM can use user-defined MSD function 
function MSD = user_msd_fn(param, d_input)
     MSD = param(1) * d_input + param(2) * d_input.^2;
end