#include <vector>
#include <cmath>
#include <complex>
#include <iostream>
#include <fftw3.h>
#include "mex.h"
#include "header/GSchur.h"
#include "header/Toeplitz.h"
#include "header/NormalToeplitz.h"

// This function computes y = Tz * z where Tz is symmetric Toeplitz. This is done in O(nlogn) by 
// embedding Tz into a circulant matrix and perform FFT.

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs != 2) {
        mexErrMsgIdAndTxt("InvalidInput", "Two input arguments required.");
    }

    // Get input data from MATLAB
    const double *acf = mxGetPr(prhs[0]);
    const double *z = mxGetPr(prhs[1]);
    //mwSize n = mxGetM(prhs[0]);
    //double* acf = mxGetPr(prhs[0]);
    int n = mxGetNumberOfElements(prhs[0]);
    int m = mxGetN(prhs[1]);
    int numrow = mxGetM(prhs[1]);
    // Create a Toeplitz structure
    Toeplitz Tz(n);

    Tz.set_acf(acf);
    
    plhs[0] = mxCreateDoubleMatrix(n, m, mxREAL);
    double *y = mxGetPr(plhs[0]); // Allocate memory for the result

    // If z is a matrix:
    for (int i = 0; i < m; i++) {
         Tz.prod(y + i*n, z + i*numrow);
    }

   // delete[] res;  
}
