#include <vector>
#include <cmath>
#include <complex>
#include <iostream>
#include <fftw3.h>
#include "mex.h"
#include "header/GSchur.h"
#include "header/Toeplitz.h"
#include "header/NormalToeplitz.h"

// This function computes "trace((Tz^{-1} * Tz1) * (Tz^{-1} * Tz2))"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs != 3) {
        mexErrMsgIdAndTxt("InvalidInput", "Three input arguments required.");
    }

    // Get input data from MATLAB
    double *acf = mxGetPr(prhs[0]);
    double *acf1 = mxGetPr(prhs[1]);
    double *acf2 = mxGetPr(prhs[2]);
   
    int n = mxGetNumberOfElements(prhs[0]);
    // Create a Toeplitz structure
    Toeplitz Tz(n);
    Tz.set_acf(acf);
    
    double traceHess = Tz.trace_hess(acf1, acf2);
    plhs[0] = mxCreateDoubleScalar(traceHess);

   // delete[] res;  
}
