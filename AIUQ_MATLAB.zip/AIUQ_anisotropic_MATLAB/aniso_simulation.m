% Simulate anisotropic 2D particle movement from a user selected stochastic
% process, and output intensity profiles.

% Input： a struct varaible 
%    model_name - The stochastic process used for simulation. The function allows
%         Brownian motion ("BM"), Fractional Brownian motion ("FBM"), Ornstein–Uhlenbeck 
%         process ("OU") and "OU + FBM". Default to be "BM".
%    sz - frame size of simulated square image with default 200.
%    len_t - number of time steps with default 200
%    noise - background noise, options from ("uniform","gaussian"), with default "gaussian".
%    I0 - background intensity (between 0 and 255), with default 20.
%    Imax - maximum intensity at the center of the particle (between 0 and
%         255), with default 255
%    M - The number of particles in images with default 50
%    pos0 - Initial position for M particles, matrix with dimension M by 2.
%    rho - The correlation between successive step and previous step in O-U
%         process (between 0 and 1) with default [0.95, 0.9].
%    H - The Hurst parameter of fractional Brownian Motion (between 0 and
%         1), with default [0.4, 0.3]
%    sigma_p - radius of the spherical particle (3xsigma_p), with default 2.
%    sigma_bm - The distance moved per time step in Brownian Motion, with default [1,0.5].
%    sigma_ou - The distance moved per time step in O-U process, with default [2,1.5].
%    sigma_fbm - The distance moved per time step in fractional Brownian
%                Motion, with default [2,1.5].

% Output:
%    sz: integer. Frame size of the intensity profile, number of pixels contained in each frame equals sz^2.
%    len_t: integer. Number of time steps.
%    noise: character. Background noise, options from ("uniform" , "gaussian").
%    model_name: character.Simulatedstochasticprocess,optionsfrom( BM , OU:,’FBM’,’OU+FBM’). 
%    M: integer. Number of particles.
%    pxsz: numeric. Size of one pixel in unit of micron, 1 for simulated data.
%    mindt: numeric. Minimum lag time, 1 for simulated data.
%    pos: matrix. Position matrix for particle trajectories.
%    intensity: matrix. Filled intensity profile.
%    num_msd: vector. Numerical mean squared displacement (MSD).
%    param: vector. Parameters used to construct MSD.
%    theor_msd: vector. Theoretical MSD.
%    sigma_2_0: vector. Variance of background noise.

function model = aniso_simulation(varargin)

    model = struct();
    
    if(length(varargin)>1)
        error('Please put all inputs into a structure');
    end

    if length(varargin) == 1
        params = varargin{:};
    else
        params = struct();
    end
    
    if(~isfield(params,'sz'))
        model.sz = [200, 200];
    else
        if length(params.sz) == 1
            model.sz = [params.sz, params.sz];
        elseif length(params.sz) > 2
            error('Frame size of simulated image should be a vector with length 2.');
        else
            model.sz = params.sz;
        end
    end
    
%     if(~isnumeric(model.frame_size))
%           error('Please input a numerical value for frame_size');
%     end   

    if(~isfield(params,'len_t'))
        model.len_t = 200;
    else   
        model.len_t = params.len_t;
    end

%     if(~isnumeric(model.len))
%         error('Please input a numerical value for len');
%     end

    if(~isfield(params,'noise'))
        noise = "gaussian";
    else
        noise = params.noise;
    end

    if(~isstring(noise))
        error('Type of background noise should be a character value.');
    end

    if(noise ~= "gaussian" && noise ~= "uniform")
       error('Type of background noise should be one of the type listed in help page.');
    end

    if(~isfield(params,'I0'))
        I0 = 20;
    else  
        I0 = params.I0;
    end
 
    if(~isnumeric(I0))
        error('Please input a numerical value for I0');
    end

    if(I0 <0 || I0 > 255)
        error('Background intensity should have value between 0 and 255.');
    end

    if(~isfield(params,'Imax'))
        Imax = 255;
    else
        Imax = params.Imax;
    end

    if(~isnumeric(Imax))
         error('Maximum intensity at the center of the particle should be a numeric value.');
    end

    if(Imax <0 || Imax > 255)
         error('Maximum intensity at the center of the particle should have value between 0 and 255.');
    end

    if(~isfield(params,'M'))
        model.M = 50;
    else
        model.M = params.M;
    end

    if(~isnumeric(model.M))
          error('Please input a numerical value for M');
    end

    if(~isfield(params,'model_name'))
        model.model_name = "BM";
    else
        model.model_name = params.model_name;
    end

    if(~isstring(model.model_name))
        error('Type of stochastic process should be a character value.');
    end

%     if(model.model_name ~= "BM" & model.model_name ~= "OU"& model.model_name ~= "FBM"& model.model_name ~= "OU+FBM")
%           error('The model allowed include: BM, OU, FBM and OU+FBM');
%     end

    if ~any(strcmp(model.model_name, {'BM', 'OU', 'FBM', 'OU+FBM'}))
         error('Type of stochastic process should be one of the type listed in help page.');
    end  


    if(~isfield(params,'pos0'))
        sz = model.sz;
        model.pos0 = [sz(2)/8+0.75*sz(2)*rand(model.M,1), sz(1)/8+0.75*sz(1)*rand(model.M,1)];
    else
        sz = model.sz;
        model.pos0 = params.pos0;
        if sum(isnan(model.pos0)) >=1
            model.pos0 = [sz(2)/8+0.75*sz(2)*rand(model.M,1), sz(1)/8+0.75*sz(1)*rand(model.M,1)];
        end
    end

    if(size(model.pos0, 2)~=2 || size(model.pos0, 1)~=model.M)
        error("Dimension of particle initial position matrix should match M by 2.");
    end

%     if(~isfield(params,'mu'))
%         mu = 0;
%     else
%         mu = params.mu;
%     end

%     if(~isnumeric(mu))
%         error('Mean velocity of the drift should be numeric.');
%     end

    if(~isfield(params,'rho'))
        rho = [0.95,0.90];
    elseif length(params.rho) == 1
            rho = [params.rho, params.rho];
    else
            rho = params.rho;
    end

    if(~isnumeric(rho))
        error('Correlation between steps in O-U process should be numeric.');
    end

%     if(~isfield(params,'drift_dir'))
%         drift_dir = false;
%     else
%         drift_dir = params.drift_dir;
%     end

%     if(~islogical(drift_dir))
%         error("drift_dir should be boolean");
%     end

    if(~isfield(params, "H"))
        H = [0.4, 0.3];
    else
        if length(params.H) == 1
            H = [params.H, params.H];
        else
            H = params.H;
        end
    end
    if(~isnumeric(H))
        error('Hurst parameter of fractional Brownian Motion should be numeric.');
    end
    if(H(1) <0 || H(2)<0 || H(1) >1 || H(2)>1)
        error('Hurst parameter of fractional Brownian Motion should have value between 0 and 1.');
    end
 
    if(~isfield(params, "sigma_p"))
        sigma_p = 2;
    else
        sigma_p = params.sigma_p;
    end
    if(~isnumeric(sigma_p))
        error('Radius of the spherical particle should be numeric.');
    end

    if(~isfield(params, "sigma_bm"))
        sigma_bm = [1, 0.5];
    else
        if length(params.sigma_bm) == 1
            sigma_bm = [params.sigma_bm, params.sigma_bm];
        else
            sigma_bm = params.sigma_bm;
        end
    end
    if(~isnumeric(sigma_bm))
        error('Distance moved per time step in Brownian Motion should be numeric.');
    end

    if(~isfield(params, "sigma_ou"))
        sigma_ou = [2, 1.5];
    else
        if length(params.sigma_ou) == 1
            sigma_ou = [params.sigma_ou, params.sigma_ou];
        else
            sigma_ou = params.sigma_ou;
        end
    end
    if(~isnumeric(sigma_ou))
        error('Distance moved per time step in Ornstein Uhlenbeck process should be numeric.');
    end

    if(~isfield(params, "sigma_fbm"))
        sigma_fbm = [2, 1.5];
    else
        if length(params.sigma_fbm) == 1
            sigma_fbm = [params.sigma_fbm, params.sigma_fbm];
        else
            sigma_fbm = params.sigma_fbm;
        end
    end
    if(~isnumeric(sigma_ou))
        error('Distance moved per time step in fractional Brownian Motion should be numeric.');
    end

    %% Start the simulation

    if strcmp(model.model_name, 'BM')
        model.pos = anisotropic_bm_particle_intensity(model.pos0, model.M, model.len_t, sigma_bm);
        model.param = sigma_bm;
    elseif strcmp(model.model_name, 'OU')
        model.pos = anisotropic_ou_particle_intensity(model.pos0, model.M, model.len_t, sigma_ou, rho);
        model.param = vertcat(rho, sigma_ou);
    elseif strcmp(model.model_name, 'FBM')
        model.pos = anisotropic_fbm_particle_intensity(model.pos0, model.M, model.len_t, sigma_fbm, H);
        model.param = vertcat(sigma_fbm,H);
    elseif strcmp(model.model_name, 'OU+FBM')
        model.pos = anisotropic_fbm_ou_particle_intensity(model.pos0, model.M, model.len_t, sigma_fbm, sigma_ou, H, rho);
        model.param = vertcat(rho,sigma_ou,sigma_fbm,H);
    end

%     % true_param = get_true_param_sim(model.param, model.model_name);
%     if strcmp(model.model_name, 'BM')
%        true_param = get_true_param_aniso_sim(model.param,  model.model_name);
%        true_param = reshape(true_param, 1, []);
%     else
%        true_param = get_true_param_aniso_sim(model.param, model.model_name);
%        %true_param = cell2mat(true_param);
%     end

    if strcmp(model.model_name, 'BM')
        model_param = zeros(size(model.param));
        for i = 1:size(model.param, 2)
            model_param(:,i) = get_true_param_aniso_sim(model.param(:,i), model.model_name);
        end
        model_param = reshape(model_param, 1, 2);
    else
        model_param = zeros(size(model.param));
        for i = 1:size(model.param, 2)
            model_param(:,i) = get_true_param_aniso_sim(model.param(:,i), model.model_name);
        end
    end

    msd_truth = zeros(model.len_t, size(model_param, 2));
    for i = 1:size(model_param, 2)
        msd_truth(:,i) = get_MSD(model_param(:,i), 0:(model.len_t-1), model.model_name, NaN);
    end
    model.theor_msd = msd_truth;

    %% Fill intensity
    sz = model.sz;
    if length(I0) == model.len_t
        if strcmp(noise, 'uniform')
            I = (rand(sz(1) * sz(2) * model.len_t, 1)-0.5) * I0;
            I = reshape(I, model.len_t, sz(1) * sz(2));
            model.sigma_2_0 = I0.^2 / 12;
        elseif strcmp(noise, 'gaussian')
            I = randn(sz(1) * sz(2) * model.len_t, 1);
            I = reshape(I, model.len_t, sz(1) * sz(2)) * sqrt(I0);
            model.sigma_2_0 = I0;
        end
    elseif length(I0) == 1
        if strcmp(noise, 'uniform')
            I = I0 * (rand(sz(1) * sz(2) *model.len_t, 1) - 0.5);
            I = reshape(I, model.len_t, sz(1) * sz(2));
            model.sigma_2_0 = I0^2/12;
        elseif strcmp(noise, 'gaussian')
            I = sqrt(I0) * randn(sz(1) * sz(2) * model.len_t, 1);
            I = reshape(I, model.len_t, sz(1) * sz(2));
            model.sigma_2_0 = I0;
        end
    end

    if length(Imax) == 1
       Ic = Imax * ones(1, model.M);
       model.intensity = fill_intensity(model.len_t, model.M, I, model.pos, Ic,...
                                        sz, sigma_p);
    end
    
    model.pxsz = 1;
    model.mindt = 1;
    model.noise = noise;
%   model.pos = array2table(model.pos, 'VariableNames', {'x', 'y'});
    model.num_msd = numerical_msd(model.pos, model.M, model.len_t);
    model.pos = array2table(model.pos);
    model.type="aniso_simulation";
end


