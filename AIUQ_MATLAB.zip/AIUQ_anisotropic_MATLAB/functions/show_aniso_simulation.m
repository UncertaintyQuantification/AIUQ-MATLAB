% Function to print the simulation strcut after the simulation model has been constructed.
% Input:
%    object: a struct variable recording simulation results
% Output:
%    Show a list of important parameters in class simulation.

function showaniso_Simulation(object)
    disp(['Frame size: ', num2str(object.sz)]);
    disp(['Number of time steps: ', num2str(object.len_t)]);
    disp(['Number of particles: ', num2str(object.M)]);
    fprintf('Stochastic process: %s\n', object.model_name);
    disp(['Variance of background noise: ', num2str(object.sigma_2_0)]);
    
   if strcmp(object.model_name, 'BM')
       fprintf('sigma_bm: %s\n', mat2str(object.param));
   elseif strcmp(object.model_name, 'OU')
       fprintf('[rho, sigma_ou]: %s\n', mat2str(object.param));
   elseif strcmp(object.model_name, 'FBM')
       fprintf('[sigma_fbm, Hurst parameter]: %s\n', mat2str(object.param));
   elseif strcmp(object.model_name, 'OU+FBM')
       fprintf('[rho, sigma_ou, sigma_fbm, Hurst parameter]: %s\n', mat2str(object.param));
   end

end
