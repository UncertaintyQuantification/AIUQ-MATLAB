% This function construct the lower and upper bound for 95% confidence interval of estimated parameters and mean squared displacement(MSD) for a given model.
% Input:
%    param_uq_range: lower and upper bound for natural logorithm of parameters in the fitted model using AIUQ method in SAM class
%    model_name: model for constructing MSD, options from ('BM', 'OU','FBM', 'OU+FBM', 'user_defined')
%    d_input: sequence of lag times
%    msd_fn: user defined mean squared displacement structure (MSD), a function of "param" parameters and "d_input" lag times
% Output:
%    A list of lower and upper bound for 95% confidence interval of estimated parameters and MSD for a given model.

function ans_list = get_est_parameters_MSD_SAM_interval(param_uq_range, model_name, d_input, msd_fn)

    theta = exp(param_uq_range(:, 1:end-1));
    sigma_2_0_est = exp(param_uq_range(:, end));
    sigma_2_0_est_lower = sigma_2_0_est(1);
    sigma_2_0_est_upper = sigma_2_0_est(2);

    est_parameters = NaN;

    if strcmp(model_name, 'BM')
        beta_lower = theta(1,1);
        beta_upper = theta(2,1);

        MSD_lower = beta_lower * d_input;
        MSD_upper = beta_upper * d_input;

        est_parameters_lower = [beta_lower, sigma_2_0_est_lower];
        est_parameters_upper = [beta_upper, sigma_2_0_est_upper];

    elseif strcmp(model_name, 'FBM')
        beta_lower = theta(1,1);
        beta_upper = theta(2,1);

        alpha_lower = 2 * theta(1, 2) / (1 + theta(1, 2));
        alpha_upper = 2 * theta(2, 2) / (1 + theta(2, 2));

        MSD_lower = NaN(1, length(d_input));
        MSD_upper = NaN(1, length(d_input));
        index_less_than_1 = d_input < 1;

        if any(index_less_than_1)
            MSD_lower(index_less_than_1) = beta_lower * d_input(index_less_than_1).^alpha_upper;
            MSD_upper(index_less_than_1) = beta_upper * d_input(index_less_than_1).^alpha_lower;
            MSD_lower(~index_less_than_1) = beta_lower * d_input(~index_less_than_1).^alpha_lower;
            MSD_upper(~index_less_than_1) = beta_upper * d_input(~index_less_than_1).^alpha_upper;

        else
            MSD_lower = beta_lower * d_input.^alpha_lower;
            MSD_upper = beta_upper * d_input.^alpha_upper;
        end

        est_parameters_lower = [beta_lower, alpha_lower, sigma_2_0_est_lower];
        est_parameters_upper = [beta_upper, alpha_upper, sigma_2_0_est_upper];

    elseif strcmp(model_name, 'OU')
        rho_lower = theta(1, 1) / (1 + theta(1, 1));
        rho_upper = theta(2, 1) / (1 + theta(2, 1));

        amplitude_lower = theta(1, 2);
        amplitude_upper = theta(2, 2);

        MSD_lower = amplitude_lower * (1 - rho_upper.^d_input);
        MSD_upper = amplitude_upper * (1 - rho_lower.^d_input);

        est_parameters_lower = [rho_lower, amplitude_lower, sigma_2_0_est_lower];
        est_parameters_upper = [rho_upper, amplitude_upper, sigma_2_0_est_lower];

    elseif strcmp(model_name, 'OU+FBM')
        rho_lower = theta(1, 1) / (1 + theta(1, 1));
        rho_upper = theta(2, 1) / (1 + theta(2, 1));

        amplitude_lower = theta(1, 2);
        amplitude_upper = theta(2, 2);

        beta_lower = theta(1, 3);
        beta_upper = theta(2, 3);

        alpha_lower = 2 * theta(1, 4) / (1 + theta(1, 4));
        alpha_upper = 2 * theta(2, 4) / (1 + theta(2, 4));

        MSD_lower = NaN(1, length(d_input));
        MSD_upper = NaN(1, length(d_input));
        index_less_than_1 = d_input < 1;

        if any(index_less_than_1)
            MSD_lower(index_less_than_1) = beta_lower * d_input(index_less_than_1).^alpha_upper;
            MSD_upper(index_less_than_1) = beta_upper * d_input(index_less_than_1).^alpha_lower;
            MSD_lower(~index_less_than_1) = beta_lower * d_input(~index_less_than_1).^alpha_lower;
            MSD_upper(~index_less_than_1) = beta_upper * d_input(~index_less_than_1).^alpha_upper;

        else
            MSD_lower = beta_lower * d_input.^alpha_lower;
            MSD_upper = beta_upper * d_input.^alpha_upper;

        end

        MSD_lower = MSD_lower + amplitude_lower * (1 - rho_upper.^d_input);
        MSD_upper = MSD_upper + amplitude_upper * (1 - rho_lower.^d_input);

        est_parameters_lower = [rho_lower, amplitude_lower, beta_lower, alpha_lower, sigma_2_0_est_lower];
        est_parameters_upper = [rho_upper, amplitude_upper, beta_upper, alpha_upper, sigma_2_0_est_upper];

    elseif strcmp(model_name, 'user_defined')
        if ismatrix(theta)
            theta_lower = theta(1, :);
            theta_upper = theta(2, :);

            MSD_lower = msd_fn(theta_lower, d_input);
            MSD_upper = msd_fn(theta_upper, d_input);

            est_parameters_lower = [theta_lower, sigma_2_0_est_lower];
            est_parameters_upper = [theta_upper, sigma_2_0_est_upper];

        else
            theta_lower = theta(1);
            theta_upper = theta(2);

            MSD_lower = msd_fn(theta_lower, d_input);
            MSD_upper = msd_fn(theta_upper, d_input);

            est_parameters_lower = [theta_lower, sigma_2_0_est_lower];
            est_parameters_upper = [theta_upper, sigma_2_0_est_upper];

        end

    end

    ans_list = struct('est_parameters_lower', est_parameters_lower, ...
                      'est_parameters_upper', est_parameters_upper, ...
                      'MSD_lower', MSD_lower, 'MSD_upper', MSD_upper);

end
