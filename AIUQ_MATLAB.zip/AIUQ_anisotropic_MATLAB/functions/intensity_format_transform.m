% Transform intensity profile with different formats, ("SST_array", "S_ST_mat", "T_SS_mat"), space by space by time array, space by (space by time) matrix, or time by (space by space) matrix, 
% into SS_T matrix. In addition, crop each frame into a square image with odd frame size.
% Input:
%    intensity: intensity profile, array or matrix
%    intensity_str: structure of the original intensity profile, options from ("SST_array", "S_ST_mat", "T_SS_mat")
%    square:  a logical evaluating to TRUE or FALSE (default) indicating whether or
%             not to crop each frame into a square such that frame size in
%             x direction equals frame size in y direction with sz_x=sz_y
%    sz: frame size of each frame. A vector of length 2 with frame size in y/(row) direction, and frame size in x/(column) direction, with default NA.
% Output:
%    A matrix of transformed intensity profile.

function intensity_transform_list = intensity_format_transform(intensity, intensity_str, square, sz)
    if nargin < 3 || isnan(square)
       square = false;
    end
    if nargin < 4
       sz = NaN;
    end
    if strcmp(intensity_str, 'SST_array')  % Two space indices and one time index, tiff
        if square
            sz_x = min([size(intensity, 1), size(intensity, 2)]);
            sz_y = min([size(intensity, 1), size(intensity, 2)]);
            if mod(sz_x, 2) == 0
                sz_x = sz_x- 1;  % Pixel dimension; total # of pixels in each image = sz^2
                sz_y = sz_y- 1; 
            end
        else
            sz_y = size(intensity, 1);
            sz_x = size(intensity, 2);
            if mod(sz_y, 2) == 0 
                sz_y = sz_y - 1;
            end
            if mod(sz_x, 2) == 0 
                sz_x = sz_x - 1;
            end
        end
        len_t = size(intensity, 3);
        
        intensity_transform = NaN(sz_x*sz_y, len_t);
        for i = 1:len_t
            % Convert the table to an array and then reshape
            %intensity_array = table2array(intensity(1:sz, 1:sz, i));
            %intensity_transform(:, i) = reshape(intensity_array(1:sz, 1:sz), [], 1);
            intensity_transform(:, i) = reshape(intensity(1:sz_y, 1:sz_x, i), [], 1);
        end
    elseif strcmp(intensity_str, 'S_ST_mat') 
        if sum(isnan(sz)) > 0
            error('Please give a vector of sz that contains frame size of each frame.');
        end
        intensity = double(intensity); % Convert intensity to matrix if necessary
        if square % Check if square is true
            sz_x = min(sz); 
            sz_y = sz_x;
            if mod(sz_x, 2) == 0 
               sz_x = sz_x - 1; 
               sz_y = sz_y - 1;
            end 
        else
            sz_y = sz(1);
            sz_x = sz(2);
            if mod(sz_y, 2) == 0
                sz_y = sz_y - 1; 
            end
            if mod(sz_x, 2) == 0
                sz_x = sz_x - 1; 
            end
        end
        len_t = size(intensity, 2) / sz(2); 
        intensity_transform = NaN(sz_x*sz_y, len_t);
        for i = 1:len_t
            % Convert the table to an array and then reshape
            %intensity_array = table2array(intensity(:, (1 + (sz + 1) * (i - 1)):sz + (sz + 1) * (i - 1)));
            %intensity_transform(:, i) = reshape(intensity_array(1:sz, 1:sz), [], 1);
            selected_x = ((1 + sz(2) * (i - 1)):(sz(2) + sz(2) * (i - 1))); 
            selected_x = selected_x(1:sz_x);
            intensity_transform(:, i) = reshape(intensity(1:sz_y, selected_x), [], 1);
        end
    elseif strcmp(intensity_str, 'T_SS_mat')  
        if sum(isnan(sz)) > 0 % Check if sz contains any NaN values
            error('Please give a vector of sz that contains frame size of each frame.');
        end
        intensity = double(intensity); % Convert intensity to matrix if necessary
        if square
            sz_x = min(sz); 
            sz_y = sz_x;
            if mod(sz_x, 2) == 0
                sz_x = sz_x - 1; % Decrease sz_x by 1 if it's even
                sz_y = sz_y - 1; % Decrease sz_y by 1 if it's even
            end
        else
            sz_y = sz(1); % Assign the first element of sz to sz_y
            sz_x = sz(2); % Assign the second element of sz to sz_x
            if mod(sz_y, 2) == 0 % Check if sz_y is even
                sz_y = sz_y - 1;
            end
            if mod(sz_x, 2) == 0 % Check if sz_x is even
                sz_x = sz_x - 1; 
            end
        end
        len_t = size(intensity, 1);
        intensity_transform = NaN(sz_x * sz_y, len_t);
        for i = 1:len_t
            %%% Convert the table to an array and then reshape
            %intensity_array = table2array(intensity(i, :));
            %intensity_matrix = reshape(intensity_array, sz + 1, sz + 1);
            intensity_matrix = reshape(intensity(i, :), sz(1), sz(2));
            intensity_transform(:, i) = reshape(intensity_matrix(1:sz_y, 1:sz_x), [], 1);
        end
    elseif strcmp(intensity_str, 'SS_T_mat')
        if sum(isnan(sz)) > 0
            error('Please give a vector of sz that contains frame size of each frame.');
        end
        intensity = double(intensity); 
    
        if square 
            sz_x = min(sz); 
            sz_y = sz_x;
            if mod(sz_x, 2) == 0 
                sz_x = sz_x - 1; 
                sz_y = sz_y - 1; 
            end
        else
            sz_y = sz(1); 
            sz_x = sz(2); 
            if mod(sz_y, 2) == 0 
                sz_y = sz_y - 1; 
            end
            if mod(sz_x, 2) == 0 
                sz_x = sz_x - 1; 
            end
        end
    
        len_t = size(intensity, 2); 
        intensity_transform = NaN(sz_x * sz_y, len_t); 
    
        for i = 1:len_t 
        intensity_mat = reshape(intensity(:, i), sz(1), sz(2)); 
        intensity_transform(:, i) = reshape(intensity_mat(1:sz_y, 1:sz_x), [], 1); 
        end
    else
        error('Invalid intensity_str');
    end
    intensity_transform_list = struct();
    intensity_transform_list.sz_x = sz_x;
    intensity_transform_list.sz_y = sz_y;
    intensity_transform_list.intensity = intensity_transform;
end
