% Transform parameters in anisotropic simulation class to parameters contained in MSD function with structure theta in get_MSD. Prepare for truth MSD construction.
% Input:
%    param_truth: parameters used in simulation class
%    model_name: stochastic process used in simulation, options from ("BM", "OU", "FBM", "OU+FBM")
% Output:
%    A vector of parameters contained in MSD with structure theta in get_MSD.
function param = get_true_param_aniso_sim(param_truth, model_name)
    if strcmp(model_name, 'BM')
        beta = param_truth(1)^2;
        param = beta;
    elseif strcmp(model_name, 'FBM')
        beta = param_truth(1)^2;
        alpha = 2 * param_truth(2);
        param = [beta, alpha];
    elseif strcmp(model_name, 'OU')
        rho = param_truth(1);
        amplitude = 2 * param_truth(2)^2;
        param = [rho, amplitude];
    elseif strcmp(model_name, 'OU+FBM')
        rho = param_truth(1);
        amplitude = 2 * param_truth(2)^2;
        beta = param_truth(3)^2;
        alpha = 2 * param_truth(4);
        param = [rho, amplitude, beta, alpha];
    end
end

