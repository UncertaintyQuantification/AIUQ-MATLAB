% The function simulates 2D particle trajectory follows anisotropic fraction Brownian Motion(fBM) process for M particles.
% Input:
%      pos0: initial position for M particles, matrix with dimension M by 2
%      M: number of particles
%      len_t: number of time steps
%      sigma: distance moved per time step
%      H: Hurst parameter of fractional Brownian Motion, value between 0 and 1
% Output:
%      Position matrix with dimension M×len_t by 2 for particle trajectory. The first M rows being the initial position pos0.
function pos = anisotropic_fbm_particle_intensity(pos0, M, len_t, sigma, H)
    pos = nan(M*len_t, 2);
    pos(:, 1) = repmat(pos0(:, 1), len_t, 1);
    pos(:, 2) = repmat(pos0(:, 2), len_t, 1);
    fBM_corr1 = corr_fBM(len_t, H(1));
    L1 = chol(sigma(1)^2 * fBM_corr1)';
    fBM_corr2 = corr_fBM(len_t, H(2));
    L2 = chol(sigma(2)^2 * fBM_corr2)';
    increments1 = L1 * randn(len_t-1, M);
    increments2 = L2 * randn(len_t-1, M);
    cumsum1 = cumsum(increments1)';
    cumsum2 = cumsum(increments2)';
    cumsum1 = reshape(cumsum1, M*(len_t-1), 1);
    cumsum2 = reshape(cumsum2, M*(len_t-1), 1);
    pos(M+1:M*len_t, 1) = pos(M+1:M*len_t, 1) + cumsum1;
    pos(M+1:M*len_t, 2) = pos(M+1:M*len_t, 2) + cumsum2;
end