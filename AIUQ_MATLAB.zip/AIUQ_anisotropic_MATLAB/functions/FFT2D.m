% Perform 2D fast Fourier transformation on SS_T matrix, record frame size for each frame, total number of frames, and sequence of lag times. 
% Calculate and record circular wave number for complete q ring.
% Input:
%    intensity_list: intensity profile, SS_T matrix
%    pxsz: size of one pixel in unit of micron
%    mindt: minimum lag time
% Output:
%    A list object containing transformed intensity profile in reciprocal space and corresponding parameters.
function ans_list = FFT2D(intensity_list, pxsz, mindt)
    sz_x = intensity_list.sz_x;
    sz_y = intensity_list.sz_y;
    intensity = intensity_list.intensity;
    len_t = size(intensity, 2);
    I_q_matrix = NaN(sz_x*sz_y, len_t);
    
    for i = 1:len_t
        I_q_matrix(:, i) = reshape(fft2(reshape(intensity(:, i), sz_y, sz_x)), [], 1);
    end
    
    ans_list = struct();
    ans_list.sz_x = sz_x;
    ans_list.sz_y = sz_y;
    ans_list.len_q = length(1:((max(sz_x,sz_y)-1)/2));
    ans_list.len_t = len_t;
    ans_list.I_q_matrix = I_q_matrix;
    ans_list.q = (1:((max(sz_x,sz_y)-1)/2)) * 2 * pi / (max(sz_x,sz_y) * pxsz);
    ans_list.input = mindt * (1:len_t);
    ans_list.d_input = ans_list.input - ans_list.input(1);
end
