% Construct initial values for the parameters to be optimized over in AIUQ method of SAM class.
% Input:
%    model_name: fitted model, options from ('BM','OU','FBM','OU+FBM','user_defined'), with Brownian motion as the default model. 
%    sigma_0_2_ini: initial value for background noise, default is NaN
%    num_param: number of parameters need to be estimated in the model.
%               If model_name is "user_defined", then num_param need to be provided to determine the length of the initial values vector.
%               Otherwise, set num_param as the exact value.
% Output:
%    A matrix with one row of initial values for the parameters to be optimized over in AIUQ method of SAM class.
function param_initial = get_initial_param(model_name, sigma_0_2_ini, num_param)
    if strcmp(model_name, 'BM')
        param_initial = log([1, sigma_0_2_ini]);
    elseif strcmp(model_name, 'FBM')
        param_initial = log([0.5, 0.5, sigma_0_2_ini]);
    elseif strcmp(model_name, 'OU')
        param_initial = log([1, 1, sigma_0_2_ini]);
    elseif strcmp(model_name, 'OU+FBM')
        param_initial = log([0.5, 0.5, 0.5, 0.5, sigma_0_2_ini]);
    elseif strcmp(model_name, 'BM_anisotropic')
        param_initial = log([1, 1, sigma_0_2_ini]);
    elseif strcmp(model_name, 'FBM_anisotropic')
        param_initial = log([0.5, 2, 0.5, 2, sigma_0_2_ini]);
    elseif strcmp(model_name, 'OU_anisotropic')
        param_initial = log([1, 1, 1, 1, sigma_0_2_ini]);
    elseif strcmp(model_name, 'OU+BM_anisotropic')
        param_initial = log([0.5, 0.5, 0.5, 0.5, 0.5, 0.5, sigma_0_2_ini]);
    elseif strcmp(model_name, 'OU+FBM_anisotropic')
        param_initial = log([0.5, 0.5, 0.5, 2, 0.5, 0.5, 0.5, 2, sigma_0_2_ini]);
    elseif strcmp(model_name, 'user_defined')
        param_initial = log([0.5 * ones(1, num_param), sigma_0_2_ini]);
    elseif strcmp(model_name, 'user_defined_anisotropic')
        param_initial = log([0.5 * ones(1, 2*num_param), sigma_0_2_ini]);    
    end
end
