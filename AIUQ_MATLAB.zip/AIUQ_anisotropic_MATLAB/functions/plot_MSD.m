% Function to plot estimated MSD with uncertainty from SAM, versus true mean squared displacement(MSD) or given reference values.
% Input:
%    object: a struct variable from "SAM"
%    msd_truth: a vector of true MSD or reference MSD value, default is NA
%    plot_title: main title of the plot. If NaN, title is "model_name" with model_name being a field in SAM class representing fitted model.
%    log_10: a logical evaluating to TRUE or FALSE indicating whether a plot in log10 scale is generated
% Output:
%    A plot of estimated MSD with uncertainty versus truth/reference values.
function plot_MSD(object, msd_truth, plot_title, log_10)
    if nargin < 4
        log_10 = true;
    end

    if nargin < 3
        plot_title = '';
    end

    if nargin < 2
        msd_truth = NaN;
    end

 if object.fit_type == 'SAM'   
    if isempty(plot_title) || isnan(plot_title)
        title_str  = object.model_name;
    else
        title_str = plot_title;
    end

    if ~isnan(msd_truth(1))
        len_t = min(length(msd_truth), length(object.d_input));
        msd_truth_here = msd_truth(2:len_t);
        if log_10
          figure('Position', [500 500 360 300]); 
          if ~isnan(object.msd_upper(1))
              polygon_x = [log10(object.d_input(2:end)) fliplr(log10(object.d_input(2:end)))];
              polygon_y = [log10(object.msd_upper(2:end)) fliplr(log10(object.msd_lower(2:end)))];
              p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]); 
              p.EdgeColor = 'none'; 
          
          hold on;
          plot(log10(object.d_input(2:len_t)), log10(msd_truth_here), 'k-', 'LineWidth', 2);
          plot(log10(object.d_input(2:end)), log10(object.msd_est(2:end)), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
          %plot(log10(object.d_input(2:end)), log10(msd_truth(2:end)), 'k-', 'LineWidth', 2);
          
          xlabel('log10(\Delta t)');
          ylabel('log10(MSD)');
          title(title_str);
          ylim([log10(min(msd_truth_here)), log10(max(msd_truth)) * 1.2]);
          % Add legend
          legend('','Reference', 'SAM', 'Location', 'SouthEast', 'FontSize', 12);
          hold off;
          else
               hold on;
               plot(log10(object.d_input(2:len_t)), log10(msd_truth_here), 'k-', 'LineWidth', 2);
               plot(log10(object.d_input(2:end)), log10(object.msd_est(2:end)), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
              %plot(log10(object.d_input(2:end)), log10(msd_truth(2:end)), 'k-', 'LineWidth', 2);
          
               xlabel('log10(\Delta t)');
               ylabel('log10(MSD)');
               title(title_str);
               ylim([log10(min(msd_truth(2:end))), log10(max(msd_truth)) * 1.2]);
               % Add legend
               legend('Reference', 'SAM', 'Location', 'SouthEast', 'FontSize', 12);
               hold off;
          end
        else
            figure('Position', [500 500 360 300]);
            if ~isnan(object.msd_upper(1))
              polygon_x = [object.d_input(2:end), fliplr(object.d_input(2:end))];
              polygon_y = [object.msd_upper(2:end), fliplr(object.msd_lower(2:end))];
              p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]); 
              p.EdgeColor = 'none'; 
          
              hold on;
            plot(object.d_input(2:len_t), msd_truth_here, 'k-', 'LineWidth', 2);
            plot(object.d_input(2:end), object.msd_est(2:end), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
            xlabel('\Delta t');
            ylabel('MSD');
            title(title_str);
            ylim([0, max(object.msd_est)* 1.2]);
           % Add legend
            legend('','Reference', 'SAM', 'Location', 'SouthEast', 'FontSize', 12);
            hold off;
            else
               hold on;         
               plot(object.d_input(2:len_t), msd_truth_here, 'k-', 'LineWidth', 2);
               plot(object.d_input(2:end), object.msd_est(2:end), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
               xlabel('\Delta t');
               ylabel('MSD');
               title(title_str);
               ylim([0, max(object.msd_est)* 1.2]);
               % Add legend
               legend('Reference', 'SAM', 'Location', 'SouthEast', 'FontSize', 12);
               hold off;
           end
         end
    else
        figure('Position', [500 500 360 300]);
        if log_10     
          if ~isnan(object.msd_upper(1))
            polygon_x = [log10(object.d_input(2:end)), fliplr(log10(object.d_input(2:end)))];
            polygon_y = [log10(object.msd_upper(2:end)), fliplr(log10(object.msd_lower(2:end)))];
            p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]); 
            p.EdgeColor = 'none'; 
          end
          hold on;
          plot(log10(object.d_input(2:end)), log10(object.msd_est(2:end)), 'b.', 'LineWidth', 2, 'MarkerSize', 8);

          legend('','SAM', 'Location', 'SouthEast', 'FontSize', 12);
          xlabel('log10(\Delta t)');
          ylabel('log10(MSD)');
          title(title_str);
          ylim([log10(min(object.msd_est(2:end))), log10(max(object.msd_est)) * 1.2]);
          hold off;
        else
          if ~isnan(object.msd_upper(1)) && length(object.msd_upper) > 1
             polygon_x = [object.d_input(2:end), fliplr(object.d_input(2:end))];
             polygon_y = [object.msd_upper(2:end), fliplr(object.msd_lower(2:end))];
             fill(polygon_x, polygon_y, 'grey80', 'EdgeColor', 'none');
          end
          hold on;
          plot(object.d_input(2:end), object.msd_est(2:end), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
          legend('SAM', 'Location', 'SouthEast', 'FontSize', 12);
        
          xlabel('\Delta t');
          ylabel('MSD');
          title(title);
          ylim([0, max(object.msd_est) * 1.2]);
          hold off;
        end
    end 
 
 elseif object.fit_type == 'aniso_SAM' 
     if isempty(plot_title) || isnan(plot_title)
         title_str  = 'Anisotropic ' + object.model_name; %strcat('Anisotropic',' ', object.model_name);
     else
         title_str = plot_title;
     end

     if ~isnan(msd_truth(1))
         if size(msd_truth, 2) ~= 2
            error('Please input a matrix with 2 columns where each column holds MSD truth for x, y directions, respectively.');
         end

         len_t = min(length(msd_truth), length(object.d_input));
         msd_true_x = msd_truth(2:len_t, 1);
         msd_true_y = msd_truth(2:len_t, 2);
         msd_x = object.msd_est(2:end,1);
         msd_y = object.msd_est(2:end,2);
         if log_10
             figure('Position', [500 500 360 300]);
             if ~isnan(object.msd_x_upper(1)) && ~isnan(object.msd_y_upper(1))
                 polygon_x = [log10(object.d_input(2:end)) fliplr(log10(object.d_input(2:end)))];
                 polygon_y = [log10(object.msd_x_upper(2:end)) fliplr(log10(object.msd_x_lower(2:end)))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;

                 polygon_x = [log10(object.d_input(2:end)) fliplr(log10(object.d_input(2:end)))];
                 polygon_y = [log10(object.msd_y_upper(2:end)) fliplr(log10(object.msd_y_lower(2:end)))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;

                 plot(log10(object.d_input(2:len_t)), log10(msd_true_x), 'k-', 'LineWidth', 2);
                 plot(log10(object.d_input(2:len_t)), log10(msd_true_y), 'k--', 'LineWidth', 2);
                 plot(log10(object.d_input(2:end)), log10(msd_x), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
                 plot(log10(object.d_input(2:end)), log10(msd_y), 'b^', 'LineWidth', 2, 'MarkerSize', 6);
                 %plot(log10(object.d_input(2:end)), log10(msd_truth(2:end)), 'k-', 'LineWidth', 2);

                 xlabel('log10(\Delta t)');
                 ylabel('log10(MSD)');
                 title(title_str);
                 ylim([log10(min([msd_true_x.', msd_true_y.'])), log10(max([msd_true_x.', msd_true_y.'])) * 1.15]);
                 % Add legend
                 legend('','','Reference x','Reference y','SAM x','SAM y', 'Location', 'NorthWest', 'FontSize', 12);
                 hold off;
             else
                 hold on;
                 plot(log10(object.d_input(2:len_t)), log10(msd_true_x), 'k-', 'LineWidth', 2);
                 plot(log10(object.d_input(2:len_t)), log10(msd_true_y), 'k--', 'LineWidth', 2);
                 plot(log10(object.d_input(2:end)), log10(msd_x), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
                 plot(log10(object.d_input(2:end)), log10(msd_y), 'b^', 'LineWidth', 2, 'MarkerSize', 6);
                 %plot(log10(object.d_input(2:end)), log10(msd_truth(2:end)), 'k-', 'LineWidth', 2);

                 xlabel('log10(\Delta t)');
                 ylabel('log10(MSD)');
                 title(title_str);
                 ylim([log10(min([msd_true_x.', msd_true_y.'])), log10(max([msd_true_x.', msd_true_y.'])) * 1.1]);
                 % Add legend
                 legend('Reference x','Reference y','SAM x','SAM y', 'Location', 'SouthEast', 'FontSize', 12);
                 hold off;
             end
         else
             figure('Position', [500 500 360 300]);
             if ~isnan(object.msd_x_upper(1)) && ~isnan(object.msd_y_upper(1))
                 polygon_x = [object.d_input(2:end), fliplr(object.d_input(2:end))];
                 polygon_y = [object.msd_x_upper(2:end), fliplr(object.msd_x_lower(2:end))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;

                 polygon_x = [object.d_input(2:end), fliplr(object.d_input(2:end))];
                 polygon_y = [object.msd_y_upper(2:end), fliplr(object.msd_y_lower(2:end))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;

                 plot(object.d_input(2:len_t), msd_true_x, 'k-', 'LineWidth', 2);
                 plot(object.d_input(2:len_t), msd_true_y, 'k--', 'LineWidth', 2);
                 plot(object.d_input(2:end), object.msd_x, 'b.', 'LineWidth', 2, 'MarkerSize', 8);
                 plot(object.d_input(2:end), object.msd_y, 'b^', 'LineWidth', 2, 'MarkerSize', 6);
                 xlabel('\Delta t');
                 ylabel('MSD');
                 title(title_str);
                 ylim([min([msd_true_x.', msd_true_y.']), max([msd_true_x.', msd_true_y.'])* 1.15]);
                 % Add legend
                 legend('','','Reference x','Reference y','SAM x','SAM y', 'Location', 'SouthEast', 'FontSize', 12);
                 hold off;
             else
                 hold on;
                 plot(object.d_input(2:len_t), msd_true_x, 'k-', 'LineWidth', 2);
                 plot(object.d_input(2:len_t), msd_true_y, 'k--', 'LineWidth', 2);
                 plot(object.d_input(2:end), msd_x, 'b.', 'LineWidth', 2, 'MarkerSize', 8);
                 plot(object.d_input(2:end), msd_y, 'b^', 'LineWidth', 2, 'MarkerSize', 6);
                 xlabel('\Delta t');
                 ylabel('MSD');
                 title(title_str);
                 ylim([log10(min([msd_true_x.', msd_true_y.'])), log10(max([msd_true_x.', msd_true_y.'])) * 1.15]);
                 % Add legend
                 legend('Reference x','Reference y','SAM x','SAM y', 'Location', 'northwest', 'FontSize', 12);
                 hold off;
             end
         end
     else
         figure('Position', [500 500 360 300]);
         if log_10
             msd_x = object.msd_est(2:end,1);
             msd_y = object.msd_est(2:end,2);
             if ~isnan(object.msd_x_upper(1)) && ~isnan(object.msd_y_upper(1))
                 polygon_x = [log10(object.d_input(2:end)) fliplr(log10(object.d_input(2:end)))];
                 polygon_y = [log10(object.msd_x_upper(2:end)) fliplr(log10(object.msd_x_lower(2:end)))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;

                 polygon_x = [log10(object.d_input(2:end)) fliplr(log10(object.d_input(2:end)))];
                 polygon_y = [log10(object.msd_y_upper(2:end)) fliplr(log10(object.msd_y_lower(2:end)))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;
             end
             hold on;

             plot(log10(object.d_input(2:end)), log10(msd_x), 'b.', 'LineWidth', 2, 'MarkerSize', 8);
             plot(log10(object.d_input(2:end)), log10(msd_y), 'b^', 'LineWidth', 2, 'MarkerSize', 6);
               
             legend('','SAM x','SAM y', 'Location', 'SouthEast', 'FontSize', 12);
             xlabel('log10(\Delta t)');
             ylabel('log10(MSD)');
             title(title_str);
             ylim([log10(min([msd_x.', msd_y.'])), log10(max([msd_x.', msd_y.'])) * 1.15]);
             hold off;
         else
             msd_x = object.msd_est(2:end,1);
             msd_y = object.msd_est(2:end,2);
             if ~isnan(object.msd_x_upper(1)) && length(object.msd_x_upper) > 1 && ~isnan(object.msd_y_upper(1)) && length(object.msd_y_upper) > 1        
                 polygon_x = [object.d_input(2:end), fliplr(object.d_input(2:end))];
                 polygon_y = [object.msd_x_upper(2:end), fliplr(object.msd_x_lower(2:end))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;

                 polygon_x = [object.d_input(2:end), fliplr(object.d_input(2:end))];
                 polygon_y = [object.msd_y_upper(2:end), fliplr(object.msd_y_lower(2:end))];
                 p=fill(polygon_x, polygon_y, [0.7 0.7 0.7]);
                 p.EdgeColor = 'none';
                 hold on;
             end

             hold on;
             plot(object.d_input(2:end), msd_x, 'b.', 'LineWidth', 2, 'MarkerSize', 8);
             plot(object.d_input(2:end), msd_y, 'b^', 'LineWidth', 2, 'MarkerSize', 6);
             legend('SAM x','SAM y', 'Location', 'SouthEast', 'FontSize', 12);

             xlabel('\Delta t');
             ylabel('MSD');
             title(title);
             ylim([min([msd_x.', msd_y.']), max([msd_x.', msd_y.'])* 1.15]);
             hold off;
         end
     end

 else
     error('Please input an SAM or aniso_SAM class object.');
 end

end
