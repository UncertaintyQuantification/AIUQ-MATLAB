% The function simulates 2D particle trajectory follows anisotropic Brownian Motion (BM) for M particles.
% Input:
%      pos0: initial position for M particles, matrix with dimension M by 2
%      M: number of particles
%      len_t: number of time steps
%      sigma: distance moved per time step
% Output:
%      Position matrix with dimension M×len_t by 2 for particle trajectory. The first M rows being the initial position pos0.
function pos = anisotropic_bm_particle_intensity(pos0, M, len_t, sigma)
    pos = zeros(M*len_t, 2);
    pos(1:M, :) = pos0;
    for i = 1:(len_t-1)
        pos(i*M + (1:M), 1) = pos((i-1)*M + (1:M), 1) + randn(M, 1) * sigma(1);
        pos(i*M + (1:M), 2) = pos((i-1)*M + (1:M), 2) + randn(M, 1) * sigma(2);
    end
end
