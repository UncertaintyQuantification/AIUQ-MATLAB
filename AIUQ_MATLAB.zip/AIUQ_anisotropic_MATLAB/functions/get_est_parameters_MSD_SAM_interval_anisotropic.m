% This function construct the lower and upper bound for 95% confidence interval of estimated parameters and mean squared displacement(MSD) for a given model.
% Input:
%    param_uq_range: lower and upper bound for natural logorithm of parameters in the fitted model using AIUQ method in SAM class
%    model_name: model for constructing MSD, options from ('BM', 'OU','FBM', 'OU+FBM', 'user_defined')
%    d_input: sequence of lag times
%    msd_fn: user defined mean squared displacement structure (MSD), a function of "param" parameters and "d_input" lag times
% Output:
%    A list of lower and upper bound for 95% confidence interval of estimated parameters and MSD for a given model.

function ans_list = get_est_parameters_MSD_SAM_interval_anisotropic(param_uq_range, model_name, d_input, msd_fn)

    theta = exp(param_uq_range(:, 1:end-1));
    sigma_2_0_est = exp(param_uq_range(:, end));
    sigma_2_0_est_lower = sigma_2_0_est(1);
    sigma_2_0_est_upper = sigma_2_0_est(2);

    est_parameters = NaN;

    if strcmp(model_name, 'BM')
        beta_x_lower = theta(1,1);
        beta_x_upper = theta(2,1);
        beta_y_lower = theta(1,2);
        beta_y_upper = theta(2,2);

        MSD_x_lower = beta_x_lower * d_input;
        MSD_x_upper = beta_x_upper * d_input;
        MSD_y_lower = beta_y_lower * d_input;
        MSD_y_upper = beta_y_upper * d_input;

      
        est_parameters_lower = [beta_x_lower, beta_y_lower, sigma_2_0_est_lower];
        est_parameters_upper = [beta_x_upper, beta_y_upper, sigma_2_0_est_upper];

    elseif strcmp(model_name, 'FBM')
        beta_x_lower = theta(1,1);
        beta_x_upper = theta(2,1);

        alpha_x_lower = 2 * theta(1, 2) / (1 + theta(1, 2));
        alpha_x_upper = 2 * theta(2, 2) / (1 + theta(2, 2));

        MSD_x_lower = NaN(1, length(d_input));
        MSD_x_upper = NaN(1, length(d_input));
        index_less_than_1 = d_input < 1;

        if any(index_less_than_1)
            MSD_x_lower(index_less_than_1) = beta_x_lower * d_input(index_less_than_1).^alpha_x_upper;
            MSD_x_upper(index_less_than_1) = beta_x_upper * d_input(index_less_than_1).^alpha_x_lower;
            MSD_x_lower(~index_less_than_1) = beta_x_lower * d_input(~index_less_than_1).^alpha_x_lower;
            MSD_x_upper(~index_less_than_1) = beta_x_upper * d_input(~index_less_than_1).^alpha_x_upper;

        else
            MSD_x_lower = beta_x_lower * d_input.^alpha_x_lower;
            MSD_x_upper = beta_x_upper * d_input.^alpha_x_upper;
        end

        beta_y_lower = theta(1,3);
        beta_y_upper = theta(2,3);

        alpha_y_lower = 2 * theta(1, 4) / (1 + theta(1, 4));
        alpha_y_upper = 2 * theta(2, 4) / (1 + theta(2, 4));

        MSD_y_lower = NaN(1, length(d_input));
        MSD_y_upper = NaN(1, length(d_input));
        index_less_than_1 = d_input < 1;

        if any(index_less_than_1)
            MSD_y_lower(index_less_than_1) = beta_y_lower * d_input(index_less_than_1).^alpha_y_upper;
            MSD_y_upper(index_less_than_1) = beta_y_upper * d_input(index_less_than_1).^alpha_y_lower;
            MSD_y_lower(~index_less_than_1) = beta_y_lower * d_input(~index_less_than_1).^alpha_y_lower;
            MSD_y_upper(~index_less_than_1) = beta_y_upper * d_input(~index_less_than_1).^alpha_y_upper;

        else
            MSD_y_lower = beta_y_lower * d_input.^alpha_y_lower;
            MSD_y_upper = beta_y_upper * d_input.^alpha_y_upper;
        end


        est_parameters_lower = [beta_x_lower, alpha_x_lower, beta_y_lower, alpha_y_lower, sigma_2_0_est_lower];
        est_parameters_upper = [beta_x_upper, alpha_x_upper, beta_y_upper, alpha_y_upper, sigma_2_0_est_upper];

    elseif strcmp(model_name, 'OU')
        rho_x_lower = theta(1, 1) / (1 + theta(1, 1));
        rho_x_upper = theta(2, 1) / (1 + theta(2, 1));

        amplitude_x_lower = theta(1, 2);
        amplitude_x_upper = theta(2, 2);

        MSD_x_lower = amplitude_x_lower * (1 - rho_x_upper.^d_input);
        MSD_x_upper = amplitude_x_upper * (1 - rho_x_lower.^d_input);

        rho_y_lower = theta(1, 3) / (1 + theta(1, 3));
        rho_y_upper = theta(2, 3) / (1 + theta(2, 3));

        amplitude_y_lower = theta(1, 4);
        amplitude_y_upper = theta(2, 4);

        MSD_y_lower = amplitude_y_lower * (1 - rho_y_upper.^d_input);
        MSD_y_upper = amplitude_y_upper * (1 - rho_y_lower.^d_input);

        est_parameters_lower = [rho_x_lower,amplitude_x_lower,rho_y_lower,amplitude_y_lower,sigma_2_0_est_lower];
        est_parameters_upper = [rho_x_upper,amplitude_x_upper,rho_y_upper,amplitude_y_upper,sigma_2_0_est_upper];

    elseif strcmp(model_name, 'OU+FBM')
        rho_x_lower = theta(1, 1) / (1 + theta(1, 1));
        rho_x_upper = theta(2, 1) / (1 + theta(2, 1));

        amplitude_x_lower = theta(1, 2);
        amplitude_x_upper = theta(2, 2);

        beta_x_lower = theta(1,3);
        beta_x_upper = theta(2,3);

        alpha_x_lower = 2 * theta(1, 4) / (1 + theta(1, 4));
        alpha_x_upper = 2 * theta(2, 4) / (1 + theta(2, 4));

        MSD_x_lower = NaN(1, length(d_input));
        MSD_x_upper = NaN(1, length(d_input));
        index_less_than_1 = d_input < 1;

        if any(index_less_than_1)
            MSD_x_lower(index_less_than_1) = beta_x_lower * d_input(index_less_than_1).^alpha_x_upper;
            MSD_x_upper(index_less_than_1) = beta_x_upper * d_input(index_less_than_1).^alpha_x_lower;
            MSD_x_lower(~index_less_than_1) = beta_x_lower * d_input(~index_less_than_1).^alpha_x_lower;
            MSD_x_upper(~index_less_than_1) = beta_x_upper * d_input(~index_less_than_1).^alpha_x_upper;

        else
            MSD_x_lower = beta_x_lower * d_input.^alpha_x_lower;
            MSD_x_upper = beta_x_upper * d_input.^alpha_x_upper;
        end

        MSD_x_lower = MSD_x_lower + amplitude_x_lower * (1 - rho_x_upper.^d_input);
        MSD_x_upper = MSD_x_upper + amplitude_x_upper * (1 - rho_x_lower.^d_input);

       
        rho_y_lower = theta(1, 5) / (1 + theta(1, 5));
        rho_y_upper = theta(2, 5) / (1 + theta(2, 5));

        amplitude_y_lower = theta(1, 6);
        amplitude_y_upper = theta(2, 6);

        beta_y_lower = theta(1,7);
        beta_y_upper = theta(2,7);

        alpha_y_lower = 2 * theta(1, 8) / (1 + theta(1, 8));
        alpha_y_upper = 2 * theta(2, 8) / (1 + theta(2, 8));

        MSD_y_lower = NaN(1, length(d_input));
        MSD_y_upper = NaN(1, length(d_input));
        index_less_than_1 = d_input < 1;

        if any(index_less_than_1)
            MSD_y_lower(index_less_than_1) = beta_y_lower * d_input(index_less_than_1).^alpha_y_upper;
            MSD_y_upper(index_less_than_1) = beta_y_upper * d_input(index_less_than_1).^alpha_y_lower;
            MSD_y_lower(~index_less_than_1) = beta_y_lower * d_input(~index_less_than_1).^alpha_y_lower;
            MSD_y_upper(~index_less_than_1) = beta_y_upper * d_input(~index_less_than_1).^alpha_y_upper;

        else
            MSD_y_lower = beta_y_lower * d_input.^alpha_y_lower;
            MSD_y_upper = beta_y_upper * d_input.^alpha_y_upper;
        end

        MSD_y_lower = MSD_y_lower + amplitude_y_lower * (1 - rho_y_lower.^d_input);
        MSD_y_upper = MSD_y_upper + amplitude_y_upper * (1 - rho_y_upper.^d_input);


        est_parameters_lower = [rho_x_lower,amplitude_x_lower,beta_x_lower,alpha_x_lower,rho_y_lower,amplitude_y_lower,beta_y_lower,alpha_y_lower,sigma_2_0_est_lower];
        est_parameters_upper = [rho_x_upper,amplitude_x_upper,beta_x_upper,alpha_x_upper,rho_y_upper,amplitude_y_upper,beta_y_upper,alpha_y_upper,sigma_2_0_est_upper];

    elseif strcmp(model_name, 'user_defined')
        if ismatrix(theta)
            theta_x_lower = theta(1, :);
            theta_x_upper = theta(2, :);
            theta_y_lower = theta(3, :);
            theta_y_upper = theta(4, :);

            MSD_x_lower = msd_fn(theta_x_lower, d_input);
            MSD_x_upper = msd_fn(theta_x_upper, d_input);
            MSD_y_lower = msd_fn(theta_y_lower, d_input);
            MSD_y_upper = msd_fn(theta_y_upper, d_input);

            est_parameters_lower = [theta_x_lower,theta_y_lower,sigma_2_0_est_lower];
            est_parameters_upper = [theta_x_upper,theta_y_upper,sigma_2_0_est_upper];

        else
            theta_lower = theta(1);
            theta_upper = theta(2);

            MSD_lower = msd_fn(theta_lower, d_input);
            MSD_upper = msd_fn(theta_upper, d_input);

            est_parameters_lower = [theta_lower, sigma_2_0_est_lower];
            est_parameters_upper = [theta_upper, sigma_2_0_est_upper];

        end

    end

    ans_list = struct('est_parameters_lower', est_parameters_lower, ...
                      'est_parameters_upper', est_parameters_upper, ...
                      'MSD_x_lower', MSD_x_lower, 'MSD_x_upper', MSD_x_upper,...
                      'MSD_y_lower', MSD_y_lower, 'MSD_y_upper', MSD_y_upper);

end
