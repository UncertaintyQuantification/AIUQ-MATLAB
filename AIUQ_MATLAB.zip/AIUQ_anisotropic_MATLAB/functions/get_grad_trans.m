% Construct parameter transformation for parameters to be optimized over in AIUQ method of SAM class
% Input:
%     theta: parameters to be optimized over
%     d_input: sequence of lag times
%     model_name: for the fitted model, options from ("BM", "OU", "FBM", "OU+FBM", "user_defined")
% Output:
%     A vector of transformed parameters to be optimized over in AIUQ method of SAM class
function grad_trans = get_grad_trans(theta, d_input, model_name)
    if strcmp(model_name, 'BM')||strcmp(model_name, 'BM_anisotropic')
        grad_trans = theta(1);
    elseif strcmp(model_name, 'FBM')||strcmp(model_name, 'FBM_anisotropic')
        beta = theta(1);
        alpha = 2 * theta(2) / (1 + theta(2));
        grad_trans = [beta, alpha * (1 - alpha/2)];
    elseif strcmp(model_name, 'OU')||strcmp(model_name, 'OU_anisotropic')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        grad_trans = [rho * (1 - rho), amplitude];
    elseif strcmp(model_name, 'OU+FBM')||strcmp(model_name, 'OU+FBM_anisotropic')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        beta = theta(3);
        alpha = 2 * theta(4) / (1 + theta(4));
        grad_trans = [rho*(1 - rho), amplitude, beta, alpha*(1 - alpha/2)];
    elseif strcmp(model_name, 'user_defined')
        grad_trans = theta;
    end
end
