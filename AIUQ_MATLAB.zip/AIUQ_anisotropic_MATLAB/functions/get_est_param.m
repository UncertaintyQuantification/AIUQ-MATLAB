% Transform parameters estimated using Maximum Likelihood Estimation (MLE) in SAM class, to parameters contained in MSD with structure theta in "get_MSD".
% Input:
%    theta: estimated parameters through MLE
%    model_name: fitted stochastic process, options from ("BM", "OU", "FBM","OU+FBM")
% Output:
%    A vector of estimated parameters after transformation with structure theta in "get_MSD".
function est_param = get_est_param(theta, model_name)
    if strcmp(model_name, 'BM')
        beta = theta(1);
        est_param = beta;
    elseif strcmp(model_name, 'FBM')
        beta = theta(1);
        alpha = 2 * theta(2) / (1 + theta(2));
        est_param = [beta, alpha];
    elseif strcmp(model_name, 'OU')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        est_param = [rho, amplitude];
    elseif strcmp(model_name, 'OU+FBM')
        rho = theta(1) / (1 + theta(1));
        amplitude = theta(2);
        beta = theta(3);
        alpha = 2 * theta(4) / (1 + theta(4));
        est_param = [rho, amplitude, beta, alpha];
    elseif strcmp(model_name, 'user_defined')
        est_param = theta;
    end
end
