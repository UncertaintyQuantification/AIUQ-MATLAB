% The function simulates 2D particle trajectory follows fraction Brownian Motion(fBM) plus a Ornstein–Uhlenbeck(OU) process for M particles.
% Input:
%      pos0: initial position for M particles, matrix with dimension M by 2
%      M: number of particles
%      len_t: number of time steps
%      sigma_fbm: distance moved per time step in fractional Brownian Motion
%      sigma_ou: distance moved per time step in Ornstein–Uhlenbeck (OU) process
%      H: Hurst parameter of fractional Brownian Motion, value between 0 and 1
%      rho: correlation between successive step and previous step in OU process, value between 0 and 1
% Output:
%      Position matrix with dimension M×len_t by 2 for particle trajectory. The first M rows being the initial position pos0.
function pos = fbm_ou_particle_intensity(pos0, M, len_t, sigma_fbm, sigma_ou, H, rho)
    pos1 = nan(M*len_t, 2);
    pos2 = nan(M*len_t, 2);
    pos = nan(M*len_t, 2);
    pos0 = pos0 + randn(M, 2) * sigma_ou;
    pos(1:M, :) = pos0;
    pos1(1:M, :) = pos0;
    sd_innovation_OU = sqrt(sigma_ou^2 * (1 - rho^2));
    
    for i = 1:(len_t-1)
        increments = randn(M, 2) * sd_innovation_OU;
        pos1(i*M + (1:M), :) = rho * (pos1((i-1)*M + (1:M), :) - pos0) + pos0 + increments;
    end

    pos2(:, 1) = repmat(pos0(:, 1), len_t, 1);
    pos2(:, 2) = repmat(pos0(:, 2), len_t, 1);
    fBM_corr = corr_fBM(len_t, H);
    L = chol(sigma_fbm^2 * fBM_corr)';
    increments1 = L * randn(len_t-1, M);
    increments2 = L * randn(len_t-1, M);
    cumsum1 = cumsum(increments1)';
    cumsum2 = cumsum(increments2)';
    cumsum1 = reshape(cumsum1, M*(len_t-1), 1);
    cumsum2 = reshape(cumsum2, M*(len_t-1), 1);
    pos2(M+1:M*len_t, 1) = pos2(M+1:M*len_t, 1) + cumsum1;
    pos2(M+1:M*len_t, 2) = pos2(M+1:M*len_t, 2) + cumsum2;
    
    pos = pos1 + pos2 - repmat(pos0, len_t, 1);
end
