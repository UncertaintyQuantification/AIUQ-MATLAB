% Function to plot the particle trajectory after the simulation class has been constructed.
% Input:
%    object: a struct variable of class simulation
%    plot_title: main title of the plot. If NA, title is "model_name with M particles" with model_name and M being field in simulation class.
% Output:
%    2D plot of particle trajectory for a given simulation from simulation class.

function plot_traj(object, plot_title)
    
        % Highlight start and end point?
        traj1 = object.pos(1:object.M:end, :);
        if nargin < 2
            if object.type == "aniso_simulation"
                plot_title = sprintf('Anisotropic %s with %d particles', object.model_name, object.M);
            else
                plot_title = sprintf('%s with %d particles', object.model_name, object.M);
            end
        end
        figure('Position', [500 500 360 300]);
        plot(traj1{:, 1}, traj1{:, 2}, 'k', 'LineWidth', 1);
        hold on;
        for i = 2:object.M
            v = object.pos(i:object.M:end, :);
            plot(v{:, 1}, v{:, 2}, 'Color', rand(1, 3), 'LineWidth', 1);
        end
        hold off;
        xlabel('frame size');
        ylabel('frame size');
        xlim([0 object.sz(2)]);
        ylim([0 object.sz(1)]);
        title(plot_title);
end
