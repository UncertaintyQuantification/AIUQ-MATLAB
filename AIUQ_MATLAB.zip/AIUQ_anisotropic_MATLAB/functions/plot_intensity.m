% Function to plot 2D intensity profile for a certain frame, default is to plot the first frame. Input can be a matrix (2D) or an array (3D).
% Input:
%    intensity: intensity profile
%    intensity_str: structure of the intensity profile, options from ("SST_array","S_ST_mat","T_SS_mat", "SS_T_mat").
%    frame: frame index
%    sz: frame size of simulated image with default [200,200].
%    plot_title: main title of the plot. If NA, title is "intensity profile for frame n" with n being the frame index in frame.
%    color: a logical evaluating to TRUE or FALSE indicating whether a colorful plot is generated 
% Output:
%    2D plot in gray scale (or with color) of selected frame.

 function plot_intensity(intensity, intensity_str, frame, sz, plot_title, color)

     if nargin < 2 || ~ischar(intensity_str)
         intensity_str = "T_SS_mat";
     end
  
     if nargin < 3 || isnan(frame)
         frame = 1;
     end
 
     if nargin < 4 
         sz = NaN;
     end
 
     if nargin < 5 || ~isstring(plot_title)
         plot_title = ['Intensity profile for frame ', num2str(frame)];
     end

     if nargin < 6 || isnan(color)
         color = false;
     end

    if numel(sz) == 1 && isnan(sz) % Check if sz is a single element NaN
        intensity_list = intensity_format_transform(intensity, intensity_str);
        intensity_trans = intensity_list.intensity;
        sz_x = intensity_list.sz_x;
        sz_y = intensity_list.sz_y;
    else
        intensity_list = intensity_format_transform(intensity, intensity_str, NaN, sz);
        intensity_trans = intensity_list.intensity;
        sz_x = intensity_list.sz_x;
        sz_y = intensity_list.sz_y;
    end


    if ~color
        figure('Position', [500 500 285 225]);
        imagesc('XData', [0 1], 'YData', [0 1], 'CData',reshape(intensity_trans(:, frame), sz_y, sz_x));
        colormap(gray(256));
        colorbar;
    else
        figure('Position', [500 500 285 225]);
        imagesc('XData', [0 1], 'YData', [0 1], 'CData', reshape(intensity_trans(:, frame), sz_y, sz_x));
        colormap(jet);
        colorbar;
    end
    xlim([0 1]);
    ylim([0 1]);
    xlabel('x');
    ylabel('y');
    title(plot_title);
end
