% This function computes the natural logarithm of the likelihood of the latent factor model for selected range of wave vectors
% of anisotropic prcoesses.
% Input:
%   param: a vector of natural logarithm of parameters
%   I_q_cur: Fourier transformed intensity profile
%   B_cur: current value of B. This parameter is determined by the noise in the system. 
%   index_q: selected index of wave number
%   I_o_q_2_ori: absolute square of Fourier transformed intensity profile,en semble over time
%   d_input: sequence of lag times
%   q_ori_ring_loc_unique_index: index for wave vector that gives a unique frequency
%   sz: frame size of the intensity profile
%   len_t: number of time steps
%   q1: wave vector in units of um^-1  in x direction
%   q2: wave vector in units of um^-1  in y direction
%   q1_unique_index: index for wave vector that give unique frequency in x direction
%   q2_unique_index: index for wave vector that give unique frequency in y direction
%   model_name: model for constructing MSD, options from ('BM', 'OU','FBM', 'OU+FBM', 'user_defined')
%   msd_fn: user-defined mean squared displacement structure (MSD), a function of "param" parameters and "d_input" lag times
%   msd_grad_fn: user-defined MSD gradient structure, a function of "param" and "d_input" 
% Output:
%   The numerical value of natural logarithm of the likelihood.
function log_lik_sum = anisotropic_neg_log_lik(param, I_q_cur, B_cur, index_q, I_o_q_2_ori, d_input, q_ori_ring_loc_unique_index, sz,...
                                      len_t, q1,q2,q1_unique_index,q2_unique_index, model_name, msd_fn, msd_grad_fn)
    
    p = (length(param) - 1)/2;
    theta_x = exp(param(1:p));
    theta_y = exp(param(p+1:2*p));
    
    if isnan(B_cur)
        sigma_2_0_hat = exp(param(2*p + 1));
        B_cur = 2 * sigma_2_0_hat;
    end

    A_cur = abs(2 * (I_o_q_2_ori - B_cur / 2));
 
%     msd.theta = theta;
%     msd.d_input = d_input;
%     msd.model_name = model_name;
%     if(isa(msd_fn, 'function_handle'))
%         msd.msd_fn = msd_fn;
%         msd.msd_grad_fn = msd_grad_fn;
%     end

%    MSD_list = Get_MSD_with_grad(msd);
    MSD_list_x = get_MSD_with_grad(theta_x,d_input,model_name, msd_fn,msd_grad_fn);
    MSD_x = MSD_list_x.MSD;
    MSD_list_y = get_MSD_with_grad(theta_y,d_input,model_name, msd_fn,msd_grad_fn);
    MSD_y = MSD_list_y.MSD;
    
    log_lik_sum = 0;
    
    eta = B_cur / 4;
    q1_zero_included = [0, q1];
    q2_zero_included = [0, q2];
    
    for i_q_selected = index_q
       for i_q_ori = 1:length(q_ori_ring_loc_unique_index{i_q_selected})
        output_re = real(I_q_cur(q_ori_ring_loc_unique_index{i_q_selected}(i_q_ori), :)) / sqrt(sz(1) * sz(2));
        output_im = imag(I_q_cur(q_ori_ring_loc_unique_index{i_q_selected}(i_q_ori), :)) / sqrt(sz(1) * sz(2));
        
        %q_selected = q(i_q_selected);
        q1_unique_index_selected = q1_unique_index{i_q_selected}(i_q_ori) + 1;
        q2_unique_index_selected = q2_unique_index{i_q_selected}(i_q_ori) + 1;

        %sigma_2 = A_cur(i_q_selected) / 4;
        sigma_2 = max(A_cur(i_q_selected)/4, 0.0001); % sometimes this is 0?
        
        %acf = sigma_2 * exp(-q_selected^2 * MSD / 4);
        acf = sigma_2 * exp(-(q1_zero_included(q1_unique_index_selected)^2 * MSD_x + q2_zero_included(q2_unique_index_selected)^2 * MSD_y) / 2);
        acf(1) = acf(1) + eta;
        acf = double(acf);
        
        % log_lik_sum = log_lik_sum + log_lik(acf, transpose(output_re)) +
        % log_lik(acf, transpose(output_im)); % This used my own function

        log_lik_sum = log_lik_sum + sum(log_density(acf, transpose(output_re)) + log_density(acf, transpose(output_im)));
    
       end
    end
    
    %log_lik_sum = log_lik_sum - 0.5 * sum(cellfun(@length, q_ori_ring_loc_unique_index)) * log(2*pi);
    log_lik_sum = log_lik_sum - 0.5 * (sum(cellfun(@length, q1_unique_index))+ sum(cellfun(@length, q2_unique_index)) ) * log(2*pi);
    log_lik_sum = -log_lik_sum;
    if isnan(log_lik_sum)
         log_lik_sum = -10^50;
    end
end
