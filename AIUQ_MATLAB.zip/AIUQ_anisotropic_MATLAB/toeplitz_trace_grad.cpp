#include <vector>
#include <cmath>
#include <complex>
#include <iostream>
#include <fftw3.h>
#include "mex.h"
#include "header/GSchur.h"
#include "header/Toeplitz.h"
#include "header/NormalToeplitz.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if(nrhs != 2) {
        mexErrMsgIdAndTxt("InvalidInput", "Two input arguments required.");
    }

    // Get pointers to the input arrays.
    double *acf = mxGetPr(prhs[0]);
    double *acf0 = mxGetPr(prhs[1]);
    int n = mxGetNumberOfElements(prhs[0]);
    // Create a Toeplitz object with the specified size and binary modulus.
    Toeplitz Tz(n, 64);
    Tz.set_acf(acf);

    // Calculate the trace of Tz^(-1)*Tz0 
    double trace_result = Tz.trace_grad(acf0);
    plhs[0] = mxCreateDoubleScalar(trace_result);
}
