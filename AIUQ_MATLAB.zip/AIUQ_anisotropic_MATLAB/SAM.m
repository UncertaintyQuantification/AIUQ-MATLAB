% Fast parameter estimation in scattering analysis of microscopy, using either AIUQ or DDM method.

% Input: a struct variable that includes:
%    intensity - intensity file
%    intensity_str - structure of the intensity profile, options from ("SST_array","S_ST_mat","T_SS_mat")
%    pxsz - size of one pixel in unit of micron, 1 for simulated data
%    sz - frame size of the intensity profile in x and y directions, number of pixels contained in each frame equals sz_x by sz_y.
%    mindt - minimum lag time, 1 for simulated data
%    AIUQ_thr - threshold for wave number selection, numeric vector of two elements with val- ues between 0 and 1.
%    anisotropic - a logical evaluating to TRUE or FALSE indicating whether anisotropic estimation should be performed
%    model_name - fitted model, options from ("BM","OU","FBM","OU+FBM","user_defined"), with Brownian motion as the default model.
%    user_model_name - the model that the user wants to fit the intensity
%                      by. Options from ("BM","OU","FBM","OU+FBM","user_defined")
%    sigma_0_2_ini - initial value for background noise. If NA, use minimum value of absolute square of intensity profile in reciprocal space.
%    param_initial - initial values for param estimation.
%    num_optim - number of optimization
%    msd_fn - user defined mean squared displacement(MSD) structure, a function of parameters and lag times. NA if model_name is not "user_defined".
%    msd_grad_fn - gradient for user defined mean squared displacement structure. If NA, then numerical gradient will be used for parameter estimation in "user_defined" model.
%    num_param - number of parameters need to be estimated in the intermediate scattering function, need to be non-NA value for "user_defined" model.
%    uncertainty - a logical evaluating to TRUE or FALSE indicating whether parameter uncer- tainty should be computed.
%    M - number of particles.
%    sim_object - whether the struct is from a simulation.
%    msd_truth - true MSD or reference MSD value.
%    method - methods for parameter estimation, options from (’AIUQ’, ’DDM’).
%    index_q_AIUQ - index range for wave number when using AIUQ method.
%    index_q_DDM - index range for wave number when using DDM method.
%    message_out - a logical evaluating to TRUE or FALSE indicating whether or not to output the message.
%    square - a logical evaluating to TRUE or FALSE indicating whether or not to crop the original intensity profile into square image.
%    output_dqt - a logical evaluating to TRUE or FALSE indicating whether or not to compute observed dynamic image structure function(Dqt).
%    output_isf - a logical evaluating to TRUE or FALSE indicating whether or not to compute empirical intermediate scattering function(ISF).
%    output_modeled_isf - a logical evaluating to TRUE or FALSE indicating whether or not to compute modeled intermediate scattering function(ISF).
%    output_modeled_dqt - a logical evaluating to TRUE or FALSE indicating whether or not to compute modeled dynamic image structure function(Dqt).
% Output: return a struct variable 

function model = SAM(varargin)

    model = struct();
    if(length(varargin)>1)
        error('Please put all inputs into a structure');
    end

    if length(varargin) == 1
        params = varargin{:};
    else
        params = struct();
    end

    if(~isfield(params, "intensity_str"))
        model.intensity_str = "T_SS_mat";
    else
        model.intensity_str = params.intensity_str;
    end

    if ~any(strcmp(model.intensity_str, {'SST_array', 'S_ST_mat', 'T_SS_mat'}))
          error("Structure of the intensity profile input should be one of the type listed in intensity_str.");
    end

    if(~isfield(params,'sz'))
        model.sz = [200, 200];
        sz = model.sz;
    else
        if length(params.sz) == 1
            model.sz = [params.sz, params.sz];
        elseif length(params.sz) > 2
            error('Frame size of simulated image should be a vector with length 2.');
        else
            model.sz = params.sz;
            sz = model.sz;
        end
    end

    if(~isfield(params,'pxsz'))
       pxsz = 1;
    else
       pxsz = params.pxsz;
    end

    if(~isnumeric(pxsz))
        error("Pixel size should be a numerical value.");
    end

    if(~isfield(params,'mindt'))
        mindt = 1;
    else
        mindt = params.mindt;
    end

    if(~isnumeric(mindt))
        error("Lag time between 2 consecutive image should be a numerical value.");
    end

    if(~isfield(params,'AIUQ_thr'))
        AIUQ_thr = [1, 1];
    else
        AIUQ_thr = params.AIUQ_thr;
    end

    if length(AIUQ_thr) == 1
        AIUQ_thr = [AIUQ_thr, 1];
    end

    if isnan(AIUQ_thr(1))
        AIUQ_thr = [1, AIUQ_thr(2)];
    end

    if isnan(AIUQ_thr(2))
        AIUQ_thr = [AIUQ_thr(1), 1];
    end

    if ~isnumeric(AIUQ_thr)
        error('AIUQ threshold should be a numerical vector.');
    end

    if AIUQ_thr(1) < 0 || AIUQ_thr(2) < 0 || AIUQ_thr(1) > 1 || AIUQ_thr(2) > 1
        error('AIUQ threshold should have values between 0 and 1.');
    end

    if(~isfield(params,'anisotropic'))
        model.anisotropic = false;
    else
        model.anisotropic = params.anisotropic;
    end

    if(~islogical(model.anisotropic))
        error("Indicator for anisotropic processes should be a logical value. ");
    end

    if(isfield(params,'sigma_0_2_ini'))
        sigma_0_2_ini = params.sigma_0_2_ini;
    else
        sigma_0_2_ini = NaN;
    end

    if(~isfield(params, "model_name"))
         model.model_name = "BM";
    elseif(isempty(params.model_name))
         model.model_name = 'user_defined';
    else
         model.model_name = params.model_name;
    end

    if(~isfield(params, "user_model_name"))
        user_model_name = model.model_name;
        model.user_model_name = user_model_name;
    else
        user_model_name = params.user_model_name;
        model.user_model_name = user_model_name;
    end

    if ~isstring(model.user_model_name)
        error('Fitted model name should be character.');
    end

    if(isfield(params, "msd_fn"))
        msd_fn = params.msd_fn;
    else
        msd_fn = NaN;
    end

    if(isfield(params, "msd_grad_fn"))
        msd_grad_fn = params.msd_grad_fn;
    else
        msd_grad_fn = NaN;
    end

    if(isfield(params, "param_initial"))
        param_initial = params.param_initial;
    else
        param_initial = NaN;
    end

    if(isfield(params, "num_optim"))
        num_optim = params.num_optim;
    else
        num_optim = 1;
    end

    if(isfield(params, "uncertainty"))
        uncertainty = params.uncertainty;
    else
        uncertainty = false;
    end

    if(~isfield(params,'M'))
        model.M = 50;
    else
        model.M = params.M;
    end
    
    if(~isfield(params,'sim_object'))
        model.sim_object = false;
    else
        model.sim_object = params.sim_object;
    end
    
    if(isfield(params, "num_param"))
        num_param = params.num_param;
    else
        num_param = NaN;
    end

    if strcmp(model.user_model_name, 'user_defined') && isnan(num_param)
        error('For user-defined model, the number of parameters that need to be estimated cannot be empty.');
    end

    if(isfield(params, "msd_truth"))
         msd_truth = params.msd_truth;
    else
         msd_truth = NaN;
    end

    if(isfield(params, "method"))
         method = params.method;
    else
         method = "AIUQ";
    end

    if(isfield(params, "index_q_AIUQ"))
         index_q_AIUQ = params.index_q_AIUQ;
    else
         index_q_AIUQ = NaN;
    end

    if(isfield(params, "index_q_DDM"))
         index_q_DDM = params.index_q_DDM;
    else
         index_q_DDM = NaN;
    end

    if(isfield(params, "message_out"))
         message_out = params.message_out;
    else
         message_out = true;
    end

    if(isfield(params, "square"))
         square = params.square;
    else
         square = false;
    end

    if(isfield(params, "output_dqt"))
         output_dqt = params.output_dqt;
    else
         output_dqt = false;
    end

    if(isfield(params, "output_isf"))
         output_isf = params.output_isf;
    else
         output_isf = false;
    end

    if(isfield(params, "output_modeled_isf"))
         output_modeled_isf = params.output_modeled_isf;
    else
         output_modeled_isf = false;
    end

    if(isfield(params, "output_modeled_dqt"))
         output_modeled_dqt = params.output_modeled_dqt;
    else
         output_modeled_dqt = false;
    end



    if(isfield(params, "sim_object") && params.sim_object)
        intensity = params.intensity;
        model.pxsz = params.pxsz;
        model.mindt = params.mindt;
        M = params.M;
        model.M = M;
        len_t = params.len_t;
        model.param_truth = get_true_param_sim(params.param, params.model_name);
        model.msd_truth = params.theor_msd;
        model.sigma_2_0_truth = params.sigma_2_0;
        sz = params.sz;
    else
        model.pxsz = pxsz;
        model.mindt = mindt;
        model.msd_truth = msd_truth;
        model.sigma_2_0_truth = NaN;
        model.param_truth = NaN;
        sz = sz;
        if(~isfield(params, "intensity"))
           error("Intensity profile can't be missing and should have one of the structure listed in intensity_str.");
        else
           intensity = params.intensity; 
        end   
    end

    if ~isstring(method)
        error('Method should be character.');
    end

    model.method = method;

    % Transform intensity into the same format and crop image into square image. Total number of pixels in each image = sz^2
    intensity_transform = intensity_format_transform(intensity, model.intensity_str, square, sz);
    fft_list = FFT2D(intensity_transform, model.pxsz, model.mindt);
    model.sz = [fft_list.sz_y, fft_list.sz_x];
    model.len_t = fft_list.len_t;
    model.len_q = fft_list.len_q;
    model.q = fft_list.q;
    model.d_input = fft_list.d_input;

    if ~isnan(index_q_DDM(1))
        if min(index_q_DDM) < 1 || max(index_q_DDM) > model.len_q
            error('Selected q range should be between 1 and half frame size.');
        end
    end

    if ~isnan(index_q_AIUQ(1))
        if min(index_q_AIUQ) < 1 || max(index_q_AIUQ) > model.len_q
            error('Selected q range should be between 1 and half frame size.');
        end
    end

    % get each q ring location index
    if model.sz(1) == model.sz(2)
        v = (-(model.sz(1)-1)/2):((model.sz(1)-1)/2);
        x = repmat(v, model.sz(1), 1);
        y = repmat(v', 1, model.sz(1));
    else
        v_x = (-(model.sz(2)-1)/2):((model.sz(2)-1)/2);
        v_y = (-(model.sz(1)-1)/2):((model.sz(1)-1)/2);
        x = repmat(v_x, model.sz(1), 1);
        y = repmat(v_y', 1, model.sz(2));
    end

    %[x, y] = meshgrid(-(model.sz-1)/2:(model.sz-1)/2, -(model.sz-1)/2:(model.sz-1)/2); %make Cartesian grid
    [THETA, RHO] = cart2pol(x, y);
    q_ring_num = RHO;
    q_ring_num = round(q_ring_num);
    
    nq_index = cell(model.len_q, 1);
    for i = 1:model.len_q
        nq_index{i} = find(q_ring_num == i);
    end
    
    q_ori_ring_loc = fftshift(q_ring_num, 3);
    
    q_ori_ring_loc_index = cell(1, model.len_q);
    total_q_ori_ring_loc_index = [];
    for i = 1:model.len_q
        q_ori_ring_loc_index{i} = find(q_ori_ring_loc == i);
        total_q_ori_ring_loc_index = vertcat(total_q_ori_ring_loc_index, q_ori_ring_loc_index{i});
    end

    q_ring_loc = q_ring_num;
    avg_I_2_ori = zeros(model.sz(1) * model.sz(2), 1);

    for i = 1:model.len_t
        avg_I_2_ori = avg_I_2_ori + abs(fft_list.I_q_matrix(:, i)).^2 / (model.sz(1)*model.sz(2));
    end
    avg_I_2_ori = avg_I_2_ori / model.len_t;

    model.I_o_q_2_ori = NaN(1, model.len_q);
    for i = 1:model.len_q
        model.I_o_q_2_ori(i) = mean(avg_I_2_ori(q_ori_ring_loc_index{i}));
    end
    I_o_q_2_ori_last = model.I_o_q_2_ori(end);

    model.B_est_ini = 2 * I_o_q_2_ori_last;
    model.A_est_ini = 2 * (model.I_o_q_2_ori - I_o_q_2_ori_last);

    num_q_max = 1;
    for i = 1:model.len_q
        if sum(model.A_est_ini(1:i)) / sum(model.A_est_ini) >= AIUQ_thr(1)
            num_q_max = i;
            break;
        end
    end
    if num_q_max / model.len_q <= AIUQ_thr(2)
        num_q_max = ceil(AIUQ_thr(2) * model.len_q);
    end

    % get unique index
    q_ori_ring_loc_unique_index = cell(1, model.len_q);
    for i = 1:model.len_q
        unique_val = unique(avg_I_2_ori(q_ori_ring_loc_index{i}));
        unique_val = unique_val(1:floor(length(q_ori_ring_loc_index{i}) / 2));
        index_selected = [];
        for j = 1:length(unique_val)
            index_selected = vertcat(index_selected, find(avg_I_2_ori == unique_val(j), 1));
        end
        q_ori_ring_loc_unique_index{i} = index_selected;
    end

    total_q_ori_ring_loc_unique_index = [];
    for i = 1:model.len_q
        total_q_ori_ring_loc_unique_index = vertcat(total_q_ori_ring_loc_unique_index, q_ori_ring_loc_unique_index{i});
    end

    if isnan(sigma_0_2_ini)
        sigma_0_2_ini = min(model.I_o_q_2_ori);
    end

    if sum(isnan(param_initial)) >= 1
        param_initial = get_initial_param(model.user_model_name, sigma_0_2_ini, num_param);
    else
        param_initial = log([param_initial, sigma_0_2_ini]);
    end


     
    if model.method == "AIUQ"
        if isnan(index_q_AIUQ(1))
           index_q_AIUQ = 1:num_q_max;
        end

        p = length(param_initial) - 1;
        num_iteration_max = 50+(p-1)*10;
        lower_bound = [-30*ones(1, p), -Inf];

        if strcmp(model.user_model_name, 'user_defined') && ~isa(msd_grad_fn, 'function_handle')
           fun = @(param) neg_log_lik(param, fft_list.I_q_matrix, NaN, index_q_AIUQ,...
                                model.I_o_q_2_ori, model.d_input, q_ori_ring_loc_unique_index,...
                                model.sz, model.len_t, model.q, model.user_model_name,...
                                msd_fn, msd_grad_fn);
           options = optimoptions('fmincon','GradConstr','off');  
           options = optimoptions(options,'GradObj','off');
           options = optimoptions(options,'MaxIterations',num_iteration_max);
           options = optimoptions(options,'StepTolerance',10^(-6));
           options = optimoptions(options,'Display','off');
           options = optimoptions(options,'HessianApproximation','lbfgs');
        else

           fun = @(param) neg_log_lik_with_grad(param, fft_list.I_q_matrix, NaN, index_q_AIUQ,...
                                model.I_o_q_2_ori, model.d_input, q_ori_ring_loc_unique_index,...
                                model.sz, model.len_t, model.q, model.user_model_name,...
                                msd_fn, msd_grad_fn);
           options = optimoptions('fmincon','SpecifyObjectiveGradient',true);  
           options = optimoptions(options,'MaxIterations',num_iteration_max);
           options = optimoptions(options,'StepTolerance',10^(-6));
           options = optimoptions(options,'Display','off');
           options = optimoptions(options,'HessianApproximation','lbfgs');
        end

        A = [];
        b = [];
        Aeq = [];
        beq = [];
        lb = lower_bound;
        ub = [];
        nonlcon = [];

        [m_param, fval] = fmincon(fun, param_initial, A,b,Aeq,beq,lb,ub,nonlcon,options);

%         if(num_optim>1)
%            for i_try = 1:(num_optim-1)
%                param_initial_try = param_initial + i_try * rand(1, p + 1);
%                if message_out
%                   fprintf('Start of another optimization, initial values: %s\n', mat2str(param_initial_try));
%                end
%                m_param_try = fmincon(fun, param_initial_try, A,b,Aeq,beq,lb,ub,nonlcon,options);
%            end
%         end
        param_est = m_param;
        model.mle = -fval;
        AIC = 2 * (length(param_est) + length(index_q_AIUQ) - (-fval));
        model.sigma_2_0_est = exp(param_est(end));
        model.param_est = get_est_param(exp(param_est), model.user_model_name);
        if strcmp(model.user_model_name, 'user_defined')
            model.param_est = model.param_est(1:end-1);
        end
      
        model.msd_est = get_MSD(model.param_est,model.d_input, model.user_model_name, msd_fn);
        %% If uncertainty
        if uncertainty && ~isnan(model.M)
             param_uq_range=param_uncertainty(param_est, fft_list.I_q_matrix, NaN,...
                                       index_q_AIUQ, model.I_o_q_2_ori,...
                                       q_ori_ring_loc_unique_index, model.sz,model.len_t,...
                                       model.d_input, model.q, model.user_model_name,...
                                       'asymptotic',model.M, num_iteration_max, lower_bound,msd_fn, msd_grad_fn);
            
            for i_p = 1:length(param_est)
                 param_uq_range(:,i_p) = [min(param_est(i_p), param_uq_range(1,i_p)), ...
                                          max(param_est(i_p), param_uq_range(2,i_p))];
            end
            SAM_range_list = get_est_parameters_MSD_SAM_interval(param_uq_range, model.user_model_name, ...
                                                                 model.d_input, msd_fn);

            model.uncertainty = uncertainty;
            model.msd_lower = SAM_range_list.MSD_lower;
            model.msd_upper = SAM_range_list.MSD_upper;
            model.param_uq_range = horzcat(SAM_range_list.est_parameters_lower.', SAM_range_list.est_parameters_upper.');

        else
            model.uncertainty = uncertainty;
            model.msd_lower = NaN;
            model.msd_upper = NaN;
            model.param_uq_range = NaN(1, 1); 
        end

        if ~output_dqt && ~output_isf
            Dqt = NaN(1, 1);
            isf = NaN(1, 1);
        elseif output_dqt && ~output_isf
            Dqt = SAM_Dqt(model.len_q, 1:model.len_q, model.len_t, fft_list.I_q_matrix, q_ori_ring_loc_unique_index, model.sz);
            isf = NaN(1, 1);
        elseif output_isf
            Dqt = NaN(model.len_q, model.len_t - 1);
            isf = NaN(model.len_q, model.len_t - 1);
            for q_j = 1:model.len_q
                index_cur = q_ori_ring_loc_unique_index{q_j};
                I_q_cur = fft_list.I_q_matrix(index_cur, :);
                for t_i = 1:(model.len_t - 1)
                    delta_I_sq = abs(I_q_cur(:, (t_i + 1):model.len_t) - I_q_cur(:, 1:(model.len_t - t_i))).^2;
                    Dqt(q_j, t_i) = mean(delta_I_sq(:) / (model.sz(1) * model.sz(2)),'all','omitnan');
                end
                if model.A_est_ini(q_j) == 0
                    break;
                end
                isf(q_j, :) = 1 - (Dqt(q_j, :) - model.B_est_ini) / model.A_est_ini(q_j);
            end
        end

     elseif strcmp(model.method, 'DDM_fixedAB')
        if length(index_q_DDM) == 1 && isnan(index_q_DDM)
            index_q_DDM = 1:model.len_q;
        end
    
        Dqt = SAM_Dqt(model.len_q, index_q_DDM, model.len_t, ...
                      fft_list.I_q_matrix,  q_ori_ring_loc_unique_index, model.sz);
        if output_isf
            isf = NaN(model.len_q, model.len_t - 1);
            for q_j = 1:model.len_q
                if model.A_est_ini(q_j) == 0
                    break;
                end
                isf(q_j, :) = 1 - (Dqt(q_j, :) - model.B_est_ini) / model.A_est_ini(q_j);
            end
        else
            isf = NaN(1, 1);
        end

        l2_est_list = theta_est_l2_dqt_fixedAB(param_initial(1:end-1), model.q, ...
                                               index_q_DDM, Dqt, model.A_est_ini, model.B_est_ini, ...
                                               model.d_input, model.user_model_name, ...
                                               msd_fn, msd_grad_fn);
    
        model.param_est = l2_est_list.param_est;
        model.msd_est = l2_est_list.msd_est;
        model.sigma_2_0_est = model.B_est_ini / 2;
        p = NaN;
        AIC = NaN;
        model.mle = NaN;
        model.param_uq_range = nan(1, 1);

    elseif strcmp(model.method, 'DDM_estAB')
        if length(index_q_DDM) == 1 && isnan(index_q_DDM)
            index_q_DDM = 1:model.len_q;
        end

        Dqt = SAM_Dqt(model.len_q, index_q_DDM, model.len_t, ...
                   fft_list.I_q_matrix, q_ori_ring_loc_unique_index, model.sz);
        
        if output_isf
            isf = NaN(model.len_q, model.len_t - 1);
            for q_j = 1:model.len_q
                if model.A_est_ini(q_j) == 0
                    break;
                end
                isf(q_j, :) = 1 - (Dqt(q_j, :) - model.B_est_ini) / model.A_est_ini(q_j);
            end
        else
            isf = NaN(1, 1);
        end

        l2_est_list = theta_est_l2_dqt_estAB(param_initial, model.A_est_ini, model.q, ...
                                             index_q_DDM, Dqt, model.d_input, model.user_model_name,...
                                             msd_fn, msd_grad_fn);

        model.param_est = l2_est_list.param_est;
        model.msd_est = l2_est_list.msd_est;
        model.sigma_2_0_est = l2_est_list.sigma_2_0_est;
        A_est = l2_est_list.A_est;
        p = NaN;
        AIC = NaN;
        model.mle = NaN;
        model.param_uq_range = nan(1, 1);
    end

    model.Dqt = Dqt;
    model.ISF = isf;

    if ~output_modeled_dqt && ~output_modeled_isf
        model.modeled_Dqt = NaN(1, 1);
        model.modeled_ISF = NaN(1, 1);
    elseif output_modeled_isf && ~output_modeled_dqt
        model.modeled_ISF = NaN(model.len_q, model.len_t - 1);
        model.modeled_Dqt = NaN(1, 1);
        for q_j = 1:model.len_q
            q_selected = model.q(q_j);
            model.modeled_ISF(q_j, :) = exp(-q_selected^2 * model.msd_est(2:end) / 4);
        end
    elseif output_modeled_dqt
        model.modeled_ISF = NaN(model.len_q, model.len_t - 1);
        model.modeled_Dqt = NaN(model.len_q, model.len_t - 1);
        for q_j = 1:model.len_q
            q_selected = model.q(q_j);
            model.modeled_ISF(q_j, :) = exp(-q_selected^2 * model.msd_est(2:end) / 4);
            if model.A_est_ini(q_j) == 0
                break;
            end
            model.modeled_Dqt(q_j, :) = model.A_est_ini(q_j) * (1 - model.modeled_ISF(q_j, :)) + model.sigma_2_0_est * 2;
        end
    end


     if strcmp(model.method, 'AIUQ')
         model.index_q = index_q_AIUQ;
     else
         model.index_q = index_q_DDM;
     end
     model.I_q = fft_list.I_q_matrix;
     model.AIC = AIC;
     model.q_ori_ring_loc_unique_index = q_ori_ring_loc_unique_index;  
     model.fit_type = "SAM";

end





    
